make clean
make -j$(nproc)
