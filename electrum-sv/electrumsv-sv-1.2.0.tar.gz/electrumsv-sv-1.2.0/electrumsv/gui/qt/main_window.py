# ElectrumSV - lightweight Bitcoin client
# Copyright (C) 2012 thomasv@gitorious
# Copyright (C) 2019 ElectrumSV developers
#
# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
# MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
# BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
# ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
# CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import base64
import csv
from decimal import Decimal
from functools import partial
import json
import os
import shutil
import threading
import time
import weakref
import webbrowser

from PyQt5.QtCore import pyqtSignal, Qt, QSize, QStringListModel, QTimer, QUrl
from PyQt5.QtGui import QKeySequence, QCursor, QDesktopServices, QPixmap
from PyQt5.QtWidgets import (
    QPushButton, QMainWindow, QTabWidget, QSizePolicy, QShortcut, QFileDialog, QMenuBar,
    QMessageBox, QGridLayout, QLineEdit, QLabel, QComboBox, QHBoxLayout,
    QVBoxLayout, QWidget, QCompleter, QMenu, QTreeWidgetItem, QStatusBar, QTextEdit,
    QInputDialog, QDialog, QToolBar, QAction, QPlainTextEdit, QTreeView
)

import electrumsv
from electrumsv import bitcoin, commands, ecc, keystore, paymentrequest, qrscanner, util
from electrumsv.address import Address, ScriptOutput
from electrumsv.app_state import app_state
from electrumsv.bitcoin import COIN, TYPE_ADDRESS, TYPE_SCRIPT
from electrumsv.exceptions import NotEnoughFunds, UserCancelled, ExcessiveFee
from electrumsv.i18n import _
from electrumsv.keystore import Hardware_KeyStore
from electrumsv.logs import logs
from electrumsv.network import broadcast_failure_reason
from electrumsv.networks import Net
from electrumsv.paymentrequest import PR_PAID
from electrumsv.transaction import Transaction, SerializationError, tx_from_str
from electrumsv.util import (
    format_time, format_satoshis, format_satoshis_plain, bh2u, bfh, format_fee_satoshis,
    get_update_check_dates, get_identified_release_signers
)
from electrumsv.version import PACKAGE_VERSION
from electrumsv.wallet import Multisig_Wallet, sweep_preparations
import electrumsv.web as web

from .amountedit import AmountEdit, BTCAmountEdit, MyLineEdit
from .coinsplitting_tab import CoinSplittingTab
from . import dialogs
from .preferences import PreferencesDialog
from .qrcodewidget import QRCodeWidget, QRDialog
from .qrtextedit import ShowQRTextEdit, ScanQRTextEdit
from .transaction_dialog import TxDialog
from .util import (
    MessageBoxMixin, ColorScheme, HelpLabel, expiration_values, ButtonsLineEdit,
    WindowModalDialog, Buttons, CopyCloseButton, MyTreeWidget, EnterButton,
    WaitingDialog, ChoicesLayout, OkButton, WWLabel, read_QIcon,
    CloseButton, CancelButton, text_dialog, filename_field, address_combo, icon_path,
    update_fixed_tree_height, UntrustedMessageDialog
)


logger = logs.get_logger("mainwindow")


class StatusBarButton(QPushButton):
    def __init__(self, icon, tooltip, func):
        QPushButton.__init__(self, icon, '')
        self.setToolTip(tooltip)
        self.setFlat(True)
        self.setMaximumWidth(25)
        self.clicked.connect(self.onPress)
        self.func = func
        self.setIconSize(QSize(25,25))

    def onPress(self, checked=False):
        '''Drops the unwanted PyQt5 "checked" argument'''
        self.func()

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Return:
            self.func()



class ElectrumWindow(QMainWindow, MessageBoxMixin):

    payment_request_ok_signal = pyqtSignal()
    payment_request_error_signal = pyqtSignal()
    notify_transactions_signal = pyqtSignal()
    new_fx_quotes_signal = pyqtSignal()
    new_fx_history_signal = pyqtSignal()
    network_signal = pyqtSignal(str, object)
    computing_privkeys_signal = pyqtSignal()
    show_privkeys_signal = pyqtSignal()
    history_updated_signal = pyqtSignal()

    def __init__(self, wallet):
        QMainWindow.__init__(self)

        self.logger = logger
        self.config = app_state.config
        self.wallet = wallet

        self.network = app_state.daemon.network
        self.invoices = wallet.invoices
        self.contacts = wallet.contacts
        self.app = app_state.app
        self.cleaned_up = False
        self.is_max = False
        self.payment_request = None
        self.checking_accounts = False
        self.qr_window = None
        self.not_enough_funds = False
        self.require_fee_update = False
        self.tx_notifications = []
        self.tx_notify_timer = None
        self.tx_dialogs = []
        self.tl_windows = []
        self.tx_external_keypairs = {}

        self.create_status_bar()
        self.need_update = threading.Event()

        self.fee_unit = self.config.get('fee_unit', 0)

        self.completions = QStringListModel()

        self.tabs = tabs = QTabWidget(self)
        self.send_tab = self.create_send_tab()
        self.receive_tab = self.create_receive_tab()
        self.addresses_tab = self.create_addresses_tab()
        self.utxo_tab = self.create_utxo_tab()
        self.console_tab = self.create_console_tab()
        self.contacts_tab = self.create_contacts_tab()
        self.coinsplitting_tab = self.create_coinsplitting_tab()

        tabs.addTab(self.create_history_tab(), read_QIcon("tab_history.png"), _('History'))
        tabs.addTab(self.send_tab, read_QIcon("tab_send.png"), _('Send'))
        tabs.addTab(self.receive_tab, read_QIcon("tab_receive.png"), _('Receive'))

        def add_optional_tab(tabs, tab, icon, description, name, default=False):
            tab.tab_icon = icon
            tab.tab_description = description
            tab.tab_pos = len(tabs)
            tab.tab_name = name
            if self.config.get('show_{}_tab'.format(name), default):
                tabs.addTab(tab, icon, description.replace("&", ""))

        add_optional_tab(tabs, self.addresses_tab, read_QIcon("tab_addresses.png"),
                         _("&Addresses"), "addresses")
        add_optional_tab(tabs, self.utxo_tab, read_QIcon("tab_coins.png"),
                         _("Co&ins"), "utxo")
        add_optional_tab(tabs, self.contacts_tab, read_QIcon("tab_contacts.png"),
                         _("Con&tacts"), "contacts")
        add_optional_tab(tabs, self.console_tab, read_QIcon("tab_console.png"),
                         _("Con&sole"), "console")
        add_optional_tab(tabs, self.coinsplitting_tab, read_QIcon("tab_coins.png"),
                         _("Coin Splitting"), "coinsplitter", True)

        tabs.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setCentralWidget(tabs)

        # Some tabs may want to be refreshed to show current state when selected.
        def on_tab_changed(to_tab_index):
            current_tab = self.tabs.currentWidget()
            if current_tab is self.coinsplitting_tab:
                self.coinsplitting_tab.update_layout()
        self.tabs.currentChanged.connect(on_tab_changed)

        if self.config.get("is_maximized"):
            self.showMaximized()

        self.init_menubar()
        self.init_toolbar()

        wrtabs = weakref.proxy(tabs)
        QShortcut(QKeySequence("Ctrl+W"), self, self.close)
        QShortcut(QKeySequence("Ctrl+Q"), self, self.close)
        QShortcut(QKeySequence("Ctrl+R"), self, self.update_wallet)
        QShortcut(QKeySequence("Ctrl+PgUp"), self,
                  lambda: wrtabs.setCurrentIndex((wrtabs.currentIndex() - 1)%wrtabs.count()))
        QShortcut(QKeySequence("Ctrl+PgDown"), self,
                  lambda: wrtabs.setCurrentIndex((wrtabs.currentIndex() + 1)%wrtabs.count()))

        for i in range(wrtabs.count()):
            QShortcut(QKeySequence("Alt+" + str(i + 1)), self,
                      lambda i=i: wrtabs.setCurrentIndex(i))

        self.payment_request_ok_signal.connect(self.payment_request_ok)
        self.payment_request_error_signal.connect(self.payment_request_error)
        self.notify_transactions_signal.connect(self.notify_transactions)
        self.history_list.setFocus(True)

        # network callbacks
        if self.network:
            self.network_signal.connect(self.on_network_qt)
            interests = ['updated', 'new_transaction', 'status',
                         'banner', 'verified', 'fee']
            # To avoid leaking references to "self" that prevent the
            # window from being GC-ed when closed, callbacks should be
            # methods of this class only, and specifically not be
            # partials, lambdas or methods of subobjects.  Hence...
            self.network.register_callback(self.on_network, interests)
            # set initial message
            self.console.showMessage(self.network.main_server.state.banner)
            self.network.register_callback(self.on_quotes, ['on_quotes'])
            self.network.register_callback(self.on_history, ['on_history'])
            self.new_fx_quotes_signal.connect(self.on_fx_quotes)
            self.new_fx_history_signal.connect(self.on_fx_history)

        self.load_wallet()
        self.app.timer.timeout.connect(self.timer_actions)

    def on_history(self, b):
        self.new_fx_history_signal.emit()

    def on_fx_history(self):
        self.history_list.refresh_headers()
        self.history_list.update()
        self.address_list.update()
        # inform things like address_dialog that there's a new history
        self.history_updated_signal.emit()

    def on_quotes(self, b):
        self.new_fx_quotes_signal.emit()

    def on_fx_quotes(self):
        self.update_status()
        # Refresh edits with the new rate
        edit = self.fiat_send_e if self.fiat_send_e.is_last_edited else self.amount_e
        edit.textEdited.emit(edit.text())
        edit = self.fiat_receive_e if self.fiat_receive_e.is_last_edited else self.receive_amount_e
        edit.textEdited.emit(edit.text())
        # History tab needs updating if it used spot
        if app_state.fx.history_used_spot:
            self.history_list.update()
            self.history_updated_signal.emit()

    def toggle_tab(self, tab):
        show = self.tabs.indexOf(tab) == -1
        self.config.set_key('show_{}_tab'.format(tab.tab_name), show)
        item_text = (_("Hide") if show else _("Show")) + " " + tab.tab_description
        tab.menu_action.setText(item_text)
        if show:
            # Find out where to place the tab
            index = len(self.tabs)
            for i in range(len(self.tabs)):
                try:
                    if tab.tab_pos < self.tabs.widget(i).tab_pos:
                        index = i
                        break
                except AttributeError:
                    pass
            self.tabs.insertTab(index, tab, tab.tab_icon, tab.tab_description.replace("&", ""))
        else:
            i = self.tabs.indexOf(tab)
            self.tabs.removeTab(i)

    def push_top_level_window(self, window):
        '''Used for e.g. tx dialog box to ensure new dialogs are appropriately
        parented.  This used to be done by explicitly providing the parent
        window, but that isn't something hardware wallet prompts know.'''
        self.tl_windows.append(window)

    def pop_top_level_window(self, window):
        self.tl_windows.remove(window)

    def top_level_window(self):
        '''Do the right thing in the presence of tx dialog windows'''
        override = self.tl_windows[-1] if self.tl_windows else None
        return self.top_level_window_recurse(override)

    def is_hidden(self):
        return self.isMinimized() or self.isHidden()

    def show_or_hide(self):
        if self.is_hidden():
            self.bring_to_top()
        else:
            self.hide()

    def bring_to_top(self):
        self.show()
        self.raise_()

    def on_exception(self, exception):
        if not isinstance(exception, UserCancelled):
            self.logger.exception("")
            self.show_error(str(exception))

    def on_error(self, exc_info):
        self.on_exception(exc_info[1])

    def on_network(self, event, *args):
        if event == 'updated':
            self.need_update.set()

        elif event == 'new_transaction':
            tx, wallet = args
            if wallet == self.wallet: # filter out tx's not for this wallet
                self.tx_notifications.append(tx)
                self.notify_transactions_signal.emit()
                self.need_update.set()
        elif event in ['status', 'banner', 'verified', 'fee']:
            # Handle in GUI thread
            self.network_signal.emit(event, args)
        else:
            self.logger.debug("unexpected network message event='%s' args='%s'", event, args)

    def on_network_qt(self, event, args=None):
        # Handle a network message in the GUI thread
        if event == 'status':
            self.update_status()
        elif event == 'banner':
            self.console.showMessage(self.network.main_server.state.banner)
        elif event == 'verified':
            self.history_list.update_item(*args)
        elif event == 'fee':
            pass
        else:
            self.logger.debug("unexpected network_qt signal event='%s' args='%s'", event, args)

    def load_wallet(self):
        wallet = self.wallet
        self.logger = logs.get_logger("mainwindow[{}]".format(self.wallet.basename()))
        self.update_recently_visited(wallet.storage.path)
        # address used to create a dummy transaction and estimate transaction fee
        self.history_list.update()
        self.address_list.update()
        self.utxo_list.update()
        self.need_update.set()
        # Once GUI has been initialized check if we want to announce something since the
        # callback has been called before the GUI was initialized
        self.notify_transactions()
        # update menus
        self.seed_menu.setEnabled(self.wallet.has_seed())
        self.update_buttons_on_seed()
        self.update_console()
        self.clear_receive_tab()
        self.request_list.update()
        self.tabs.show()
        self.init_geometry()
        if self.config.get('hide_gui') and self.app.tray.isVisible():
            self.hide()
        else:
            self.show()
        self.watching_only_changed()
        self.history_updated_signal.emit()
        wallet.create_gui_handlers(self)

    def init_geometry(self):
        winpos = self.wallet.storage.get("winpos-qt")
        try:
            screen = self.app.desktop().screenGeometry()
            assert screen.contains(QRect(*winpos))
            self.setGeometry(*winpos)
        except:
            self.logger.debug("using default geometry")
            self.setGeometry(100, 100, 840, 400)

    def watching_only_changed(self):
        title = f'ElectrumSV {PACKAGE_VERSION} ({Net.NAME})  -  {self.wallet.basename()}'
        extra = [self.wallet.storage.get('wallet_type', '?')]
        if self.wallet.is_watching_only():
            self.warn_if_watching_only()
            extra.append(_('watching only'))
        title += '  [%s]'% ', '.join(extra)
        self.setWindowTitle(title)
        self.password_menu.setEnabled(self.wallet.can_change_password())
        self.import_privkey_menu.setVisible(self.wallet.can_import_privkey())
        self.import_address_menu.setVisible(self.wallet.can_import_address())
        self.export_menu.setEnabled(self.wallet.can_export())

    def warn_if_watching_only(self):
        if self.wallet.is_watching_only():
            msg = ' '.join([
                _("This wallet is watching-only."),
                _("This means you will not be able to spend Bitcoin SV with it."),
                _("Make sure you own the seed phrase or the private keys, "
                  "before you request Bitcoin SV to be sent to this wallet.")
            ])
            self.show_warning(msg, title=_('Information'))

    def open_wallet(self):
        try:
            wallet_folder = self.get_wallet_folder()
        except FileNotFoundError as e:
            self.show_error(str(e))
            return
        if not os.path.exists(wallet_folder):
            wallet_folder = None
        filename, __ = QFileDialog.getOpenFileName(self, "Select your wallet file", wallet_folder)
        if not filename:
            return
        self.app.new_window(filename)

    def backup_wallet(self):
        path = self.wallet.storage.path
        wallet_folder = os.path.dirname(path)
        filename, __ = QFileDialog.getSaveFileName(
            self, _('Enter a filename for the copy of your wallet'), wallet_folder)
        if not filename:
            return

        new_path = os.path.join(wallet_folder, filename)
        if new_path != path:
            try:
                # Copy file contents
                shutil.copyfile(path, new_path)

                # Copy file attributes if possible
                # (not supported on targets like Flatpak documents)
                try:
                    shutil.copystat(path, new_path)
                except (IOError, os.error):
                    pass

                self.show_message(_("A copy of your wallet file was created in")
                                  +" '%s'" % str(new_path), title=_("Wallet backup created"))
            except (IOError, os.error) as reason:
                self.show_critical(_("ElectrumSV was unable to copy your wallet file "
                                     "to the specified location.") + "\n" + str(reason),
                                   title=_("Unable to create backup"))

    def update_recently_visited(self, filename):
        recent = self.config.get('recently_open', [])
        try:
            sorted(recent)
        except:
            recent = []
        if filename in recent:
            recent.remove(filename)
        recent.insert(0, filename)
        recent2 = []
        for k in recent:
            if os.path.exists(k):
                recent2.append(k)
        recent = recent2[:5]
        self.config.set_key('recently_open', recent)
        self.recently_visited_menu.clear()
        for i, k in enumerate(sorted(recent)):
            b = os.path.basename(k)
            def loader(k):
                return lambda: self.app.new_window(k)
            self.recently_visited_menu.addAction(
                b, loader(k)).setShortcut(QKeySequence("Ctrl+%d"%(i+1)))
        self.recently_visited_menu.setEnabled(len(recent))

    def get_wallet_folder(self):
        return os.path.dirname(os.path.abspath(self.config.get_wallet_path()))

    def new_wallet(self):
        try:
            wallet_folder = self.get_wallet_folder()
        except FileNotFoundError as e:
            self.show_error(str(e))
            return
        i = 1
        while True:
            filename = "wallet_%d" % i
            if filename in os.listdir(wallet_folder):
                i += 1
            else:
                break
        full_path = os.path.join(wallet_folder, filename)
        self.app.start_new_window(full_path, None)

    def init_menubar(self):
        menubar = QMenuBar()

        file_menu = menubar.addMenu(_("&File"))
        self.recently_visited_menu = file_menu.addMenu(_("&Recently open"))
        file_menu.addAction(_("&Open"), self.open_wallet).setShortcut(QKeySequence.Open)
        file_menu.addAction(_("&New/Restore"), self.new_wallet).setShortcut(QKeySequence.New)
        file_menu.addAction(_("&Save Copy"), self.backup_wallet).setShortcut(QKeySequence.SaveAs)
        file_menu.addAction(_("Delete"), self.remove_wallet)
        file_menu.addSeparator()
        file_menu.addAction(_("&Quit"), self.close)

        wallet_menu = menubar.addMenu(_("&Wallet"))
        wallet_menu.addAction(_("&Information"), self.show_master_public_keys)
        if Net.NAME == "testnet":
            def temp_func():
                from importlib import reload
                from . import wallet_wizard
                reload(wallet_wizard)
                wallet_wizard.open_wallet_wizard()
            wallet_menu.addAction(_("&New Wizard"), temp_func)
        wallet_menu.addSeparator()
        self.password_menu = wallet_menu.addAction(_("&Password"), self.change_password_dialog)
        self.seed_menu = wallet_menu.addAction(_("&Seed"), self.show_seed_dialog)
        self.private_keys_menu = wallet_menu.addMenu(_("&Private keys"))
        self.private_keys_menu.addAction(_("&Sweep"), self.sweep_key_dialog)
        self.import_privkey_menu = self.private_keys_menu.addAction(_("&Import"),
                                                                    self.do_import_privkey)
        self.export_menu = self.private_keys_menu.addAction(_("&Export"),
                                                            self.export_privkeys_dialog)
        self.import_address_menu = wallet_menu.addAction(_("Import addresses"),
                                                         self.import_addresses)
        wallet_menu.addSeparator()

        labels_menu = wallet_menu.addMenu(_("&Labels"))
        labels_menu.addAction(_("&Import"), self.do_import_labels)
        labels_menu.addAction(_("&Export"), self.do_export_labels)
        contacts_menu = wallet_menu.addMenu(_("Contacts"))
        contacts_menu.addAction(_("&New"), self.new_contact_dialog)
        contacts_menu.addAction(_("Import"), self.contact_list.import_contacts)
        invoices_menu = wallet_menu.addMenu(_("Invoices"))
        invoices_menu.addAction(_("Import"), self.invoice_list.import_invoices)
        hist_menu = wallet_menu.addMenu(_("&History"))
        hist_menu.addAction("Export", self.export_history_dialog)

        wallet_menu.addSeparator()
        wallet_menu.addAction(_("Find"), self.toggle_search).setShortcut(QKeySequence("Ctrl+F"))

        def add_toggle_action(view_menu, tab):
            is_shown = self.tabs.indexOf(tab) > -1
            item_name = (_("Hide") if is_shown else _("Show")) + " " + tab.tab_description
            tab.menu_action = view_menu.addAction(item_name, lambda: self.toggle_tab(tab))

        view_menu = menubar.addMenu(_("&View"))
        add_toggle_action(view_menu, self.addresses_tab)
        add_toggle_action(view_menu, self.utxo_tab)
        add_toggle_action(view_menu, self.contacts_tab)
        add_toggle_action(view_menu, self.coinsplitting_tab)
        add_toggle_action(view_menu, self.console_tab)

        tools_menu = menubar.addMenu(_("&Tools"))

        tools_menu.addAction(_("Preferences"), self.preferences_dialog)
        tools_menu.addAction(_("&Network"), lambda: self.app.show_network_dialog(self))
        tools_menu.addSeparator()
        tools_menu.addAction(_("&Sign/verify message"), self.sign_verify_message)
        tools_menu.addAction(_("&Encrypt/decrypt message"), self.encrypt_message)
        tools_menu.addSeparator()

        paytomany_menu = tools_menu.addAction(_("&Pay to many"), self.paytomany)

        raw_transaction_menu = tools_menu.addMenu(_("&Load transaction"))
        raw_transaction_menu.addAction(_("&From file"), self.do_process_from_file)
        raw_transaction_menu.addAction(_("&From text"), self.do_process_from_text)
        raw_transaction_menu.addAction(_("&From the blockchain"), self.do_process_from_txid)
        raw_transaction_menu.addAction(_("&From QR code"), self.do_process_from_qrcode)
        self.raw_transaction_menu = raw_transaction_menu

        help_menu = menubar.addMenu(_("&Help"))
        help_menu.addAction(_("&About"), self.show_about)
        help_menu.addAction(_("&Check for updates"), self.show_update_check)
        help_menu.addAction(_("&Official website"), lambda: webbrowser.open("http://electrumsv.io"))
        help_menu.addSeparator()
        help_menu.addAction(_("Documentation"),
            lambda: webbrowser.open("http://electrumsv.readthedocs.io/")
        ).setShortcut(QKeySequence.HelpContents)
        help_menu.addAction(_("&Report Bug"), self.show_report_bug)
        help_menu.addSeparator()
        help_menu.addAction(_("&Donate to server"), self.donate_to_server)

        self.setMenuBar(menubar)

    def init_toolbar(self):
        self.toolbar = toolbar = QToolBar(self)
        icon_size = self.app.dpi / 5.8
        toolbar.setMovable(False)
        toolbar.setIconSize(QSize(icon_size, icon_size))
        toolbar.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)

        preferences_action = QAction(read_QIcon("preferences.png"), _("Preferences"), self)
        preferences_action.triggered.connect(self.preferences_dialog)
        toolbar.addAction(preferences_action)

        network_action = QAction(read_QIcon("network.png"), _("Network"), self)
        network_action.triggered.connect(lambda: self.app.show_network_dialog(self))
        toolbar.addAction(network_action)

        log_action = QAction(read_QIcon("icons8-moleskine-80.png"), _("Log Viewer"), self)
        log_action.triggered.connect(self.app.show_log_viewer)
        toolbar.addAction(log_action)

        self._update_check_state = "default"
        update_action = QAction(
            read_QIcon("icons8-available-updates-80-blue"), _("Update Check"), self)
        def _update_show_menu(checked: bool = False):
            self._update_menu.exec(QCursor.pos())
        update_action.triggered.connect(_update_show_menu)
        self._update_action = update_action
        toolbar.addAction(update_action)
        self._update_check_toolbar_update()

        toolbar.insertSeparator(update_action)

        self.addToolBar(toolbar)
        self.setUnifiedTitleAndToolBarOnMac(True)

    def _update_check_toolbar_update(self):
        update_check_state = "default"
        check_result = self.config.get('last_update_check')
        stable_version = "?"
        if check_result is not None:
            # The latest stable release date, the date of the build we are using.
            stable_result = check_result["stable"]
            stable_signers = get_identified_release_signers(stable_result)
            if stable_signers:
                release_date, current_date = get_update_check_dates(stable_result["date"])
                if release_date > current_date:
                    if time.time() - release_date.timestamp() < 24 * 60 * 60:
                        update_check_state = "update-present-immediate"
                    else:
                        update_check_state = "update-present-prolonged"
                stable_version = stable_result["version"]

        def _on_check_for_updates(checked: bool=False):
            self.show_update_check()

        def _on_view_pending_update(checked: bool=False):
            QDesktopServices.openUrl(QUrl("https://electrumsv.io/download/"))

        menu = QMenu()
        self._update_menu = menu
        self._update_check_action = menu.addAction(
            _("Check for Updates"), _on_check_for_updates)

        if update_check_state == "default":
            icon_path = "icons8-available-updates-80-blue"
            icon_text = _("Updates")
            tooltip = _("Check for Updates")
            menu.setDefaultAction(self._update_check_action)
        elif update_check_state == "update-present-immediate":
            icon_path = "icons8-available-updates-80-yellow"
            icon_text = f"{stable_version}"
            tooltip = _("A newer version of ElectrumSV is available, and "+
                "was released on {0:%c}").format(release_date)
            self._update_view_pending_action = menu.addAction(
                _("View Pending Update"), _on_view_pending_update)
            menu.setDefaultAction(self._update_view_pending_action)
        elif update_check_state == "update-present-prolonged":
            icon_path = "icons8-available-updates-80-red"
            icon_text = f"{stable_version}"
            tooltip = _("A newer version of ElectrumSV is available, and "+
                "was released on {0:%c}").format(release_date)
            self._update_view_pending_action = menu.addAction(
                _("View Pending Update"), _on_view_pending_update)
            menu.setDefaultAction(self._update_view_pending_action)
        # Apply the update state.
        self._update_action.setMenu(menu)
        self._update_action.setIcon(read_QIcon(icon_path))
        self._update_action.setText(icon_text)
        self._update_action.setToolTip(tooltip)
        self._update_check_state = update_check_state

    def on_update_check(self, success, result):
        if success:
            stable_result = result["stable"]
            stable_signers = get_identified_release_signers(stable_result)
            if stable_signers:
                # The latest stable release date, the date of the build we are using.
                stable_date_string = stable_result["date"]
                release_date, current_date = get_update_check_dates(stable_date_string)
                if release_date > current_date:
                    self.app.tray.showMessage(
                        "ElectrumSV",
                        _("A new version of ElectrumSV, version {}, is available for download")
                            .format(stable_result["version"]),
                        read_QIcon("electrum_dark_icon"), 20000)

        self._update_check_toolbar_update()

    def donate_to_server(self):
        server = self.network.main_server
        addr = server.state.donation_address
        if Address.is_valid(addr):
            addr = Address.from_string(addr)
            self.pay_to_URI(web.create_URI(addr, 0, _('Donation for {}').format(server.host)))
        else:
            self.show_error(_('The server {} has not provided a valid donation address')
                            .format(server))

    def show_about(self):
        QMessageBox.about(self, "ElectrumSV",
            _("Version")+" %s" % (self.wallet.electrum_version) + "\n\n" +
            _("ElectrumSV's focus is speed, with low resource usage and simplifying "
              "Bitcoin SV. You do not need to perform regular backups, because your "
              "wallet can be recovered from a secret phrase that you can memorize or "
              "write on paper. Startup times are instant because it operates in "
              "conjunction with high-performance servers that handle the most complicated "
              "parts of the Bitcoin SV system."  + "\n\n" +
              _("Uses icons from the Icons8 icon pack (icons8.com).")))

    def show_update_check(self):
        from . import update_check
        update_check.UpdateCheckDialog()

    def show_report_bug(self):
        msg = ' '.join([
            _("Please report any bugs as issues on github:<br/>"),
            "<a href=\"https://github.com/ElectrumSV/ElectrumSV/issues"
            "\">https://github.com/ElectrumSV/ElectrumSV/issues</a><br/><br/>",
            _("Before reporting a bug, upgrade to the most recent version of ElectrumSV "
              "(latest release or git HEAD), and include the version number in your report."),
            _("Try to explain not only what the bug is, but how it occurs.")
         ])
        self.show_message(msg, title="ElectrumSV - " + _("Reporting Bugs"))

    last_notify_tx_time = 0.0
    notify_tx_rate = 30.0

    def notify_tx_cb(self):
        n_ok = 0
        if self.network and self.network.is_connected() and self.wallet:
            num_txns = len(self.tx_notifications)
            if num_txns:
                # Combine the transactions
                total_amount = 0
                for tx in self.tx_notifications:
                    if tx:
                        is_relevant, is_mine, v, fee = self.wallet.get_wallet_delta(tx)
                        if v > 0 and is_relevant:
                            total_amount += v
                            n_ok += 1
                if n_ok:
                    self.logger.debug("Notifying GUI %d tx", n_ok)
                    if n_ok > 1:
                        self.notify(_("{} new transactions received: Total amount received "
                                      "in the new transactions {}")
                                    .format(n_ok, self.format_amount_and_units(total_amount)))
                    else:
                        self.notify(_("New transaction received: {}").format(
                            self.format_amount_and_units(total_amount)))
        self.tx_notifications = list()
        self.last_notify_tx_time = time.time() if n_ok else self.last_notify_tx_time
        if self.tx_notify_timer:
            self.tx_notify_timer.stop()
            self.tx_notify_timer = None


    def notify_transactions(self):
        if self.tx_notify_timer or not len(self.tx_notifications) or self.cleaned_up:
            # common case: extant notify timer -- we already enqueued to notify. So bail
            # and wait for timer to handle it.
            return
        elapsed = time.time() - self.last_notify_tx_time
        if elapsed < self.notify_tx_rate:
            # spam control. force tx notify popup to not appear more often than every 30
            # seconds by enqueing the request for a timer to handle it sometime later
            self.tx_notify_timer = QTimer(self)
            self.tx_notify_timer.setSingleShot(True)
            self.tx_notify_timer.timeout.connect(self.notify_tx_cb)
            when = (self.notify_tx_rate - elapsed)
            self.logger.debug("Notify spam control: will notify GUI of %d new tx's in %f seconds",
                              len(self.tx_notifications), when)
            self.tx_notify_timer.start(when * 1e3) # time in ms
        else:
            # it's been a while since we got a tx notify -- so do it immediately (no timer
            # necessary)
            self.notify_tx_cb()


    def notify(self, message):
        self.app.tray.showMessage("ElectrumSV", message,
                                  read_QIcon("electrum_dark_icon"), 20000)

    # custom wrappers for getOpenFileName and getSaveFileName, that remember the path
    # selected by the user
    def getOpenFileName(self, title, filter = ""):
        directory = self.config.get('io_dir', os.path.expanduser('~'))
        fileName, __ = QFileDialog.getOpenFileName(self, title, directory, filter)
        if fileName and directory != os.path.dirname(fileName):
            self.config.set_key('io_dir', os.path.dirname(fileName), True)
        return fileName

    def getOpenFileNames(self, title, filter = ""):
        directory = self.config.get('io_dir', os.path.expanduser('~'))
        fileNames, __ = QFileDialog.getOpenFileNames(self, title, directory, filter)
        if fileNames and directory != os.path.dirname(fileNames[0]):
            self.config.set_key('io_dir', os.path.dirname(fileNames[0]), True)
        return fileNames

    def getSaveFileName(self, title, filename, filter = ""):
        directory = self.config.get('io_dir', os.path.expanduser('~'))
        path = os.path.join( directory, filename )
        fileName, __ = QFileDialog.getSaveFileName(self, title, path, filter)
        if fileName and directory != os.path.dirname(fileName):
            self.config.set_key('io_dir', os.path.dirname(fileName), True)
        return fileName

    def timer_actions(self):
        # Note this runs in the GUI thread
        if self.need_update.is_set():
            self.need_update.clear()
            self.update_wallet()

        # resolve aliases
        # FIXME this is a blocking network call that has a timeout of 5 sec
        self.payto_e.resolve()
        # update fee
        if self.require_fee_update:
            self.do_update_fee()
            self.require_fee_update = False

    def format_amount(self, x, is_diff=False, whitespaces=False):
        return format_satoshis(x, app_state.num_zeros, app_state.decimal_point,
                               is_diff=is_diff, whitespaces=whitespaces)

    def format_amount_and_units(self, amount):
        text = self.format_amount(amount) + ' ' + app_state.base_unit()
        x = app_state.fx.format_amount_and_units(amount)
        if text and x:
            text += ' (%s)'%x
        return text

    def get_amount_and_units(self, amount):
        bitcoin_text = self.format_amount(amount) + ' ' + app_state.base_unit()
        fiat_text = app_state.fx.format_amount_and_units(amount)
        return bitcoin_text, fiat_text

    def format_fee_rate(self, fee_rate):
        return format_fee_satoshis(fee_rate/1000, app_state.num_zeros) + ' sat/B'

    def connect_fields(self, window, btc_e, fiat_e, fee_e):

        def edit_changed(edit):
            if edit.follows:
                return
            edit.setStyleSheet(ColorScheme.DEFAULT.as_stylesheet())
            fiat_e.is_last_edited = (edit == fiat_e)
            amount = edit.get_amount()
            rate = app_state.fx.exchange_rate() if app_state.fx else None
            if rate is None or amount is None:
                if edit is fiat_e:
                    btc_e.setText("")
                    if fee_e:
                        fee_e.setText("")
                else:
                    fiat_e.setText("")
            else:
                if edit is fiat_e:
                    btc_e.follows = True
                    btc_e.setAmount(int(amount / Decimal(rate) * COIN))
                    btc_e.setStyleSheet(ColorScheme.BLUE.as_stylesheet())
                    btc_e.follows = False
                    if fee_e:
                        window.update_fee()
                else:
                    fiat_e.follows = True
                    fiat_e.setText(app_state.fx.ccy_amount_str(
                        amount * Decimal(rate) / COIN, False))
                    fiat_e.setStyleSheet(ColorScheme.BLUE.as_stylesheet())
                    fiat_e.follows = False

        btc_e.follows = False
        fiat_e.follows = False
        fiat_e.textChanged.connect(partial(edit_changed, fiat_e))
        btc_e.textChanged.connect(partial(edit_changed, btc_e))
        fiat_e.is_last_edited = False

    def update_status(self):
        if not self.wallet:
            return

        network_text = _("Connected")
        balance_status = None
        fiat_status = None

        if self.network is None:
            network_text = _("Offline")
        elif self.network.is_connected():
            server_height = self.network.get_server_height()
            server_lag = self.network.get_local_height() - server_height
            # Server height can be 0 after switching to a new server
            # until we get a headers subscription request response.
            # Display the synchronizing message in that case.
            if not self.wallet.is_synchronized() or server_height == 0:
                network_text = _("Synchronizing...")
            elif server_lag > 1:
                network_text = _("Server {} blocks behind").format(server_lag)
            else:
                c, u, x = self.wallet.get_balance()
                balance_status = self.get_amount_and_units(c)

                # append fiat balance and price
                if app_state.fx.is_enabled():
                    fiat_status = app_state.fx.get_fiat_status(c + u + x,
                        app_state.base_unit(), app_state.decimal_point)
        else:
            network_text = _("Not connected")

        self.set_status_bar_balance(balance_status)
        self.set_status_bar_fiat(fiat_status)
        self.network_label.setText(network_text)

    def update_wallet(self):
        self.update_status()
        if self.wallet.is_synchronized() or not self.network or not self.network.is_connected():
            self.update_tabs()

    def update_tabs(self):
        self.history_list.update()
        self.request_list.update()
        self.address_list.update()
        self.utxo_list.update()
        self.contact_list.update()
        self.invoice_list.update()
        self.update_completions()
        self.history_updated_signal.emit()

    def create_history_tab(self):
        from .history_list import HistoryList
        self.history_list = l = HistoryList(self)
        l.searchable_list = l
        return l

    def show_address(self, addr):
        from . import address_dialog
        d = address_dialog.AddressDialog(self, addr)
        d.exec_()

    def show_transaction(self, tx, tx_desc=None, prompt_if_unsaved=False):
        '''tx_desc is set only for txs created in the Send tab'''
        tx_dialog = TxDialog(tx, self, tx_desc, prompt_if_unsaved)
        tx_dialog.finished.connect(partial(self.on_tx_dialog_finished, tx_dialog))
        self.tx_dialogs.append(tx_dialog)
        tx_dialog.show()
        return tx_dialog

    def on_tx_dialog_finished(self, tx_dialog, status):
        tx_dialog.finished.disconnect()
        self.tx_dialogs.remove(tx_dialog)

    def create_receive_tab(self):
        # A 4-column grid layout.  All the stretch is in the last column.
        # The exchange rate plugin adds a fiat widget in column 2
        self.receive_grid = grid = QGridLayout()
        grid.setSpacing(8)
        grid.setColumnStretch(3, 1)

        self.receive_address = None
        self.receive_address_e = ButtonsLineEdit()
        self.receive_address_e.addCopyButton(self.app)
        self.receive_address_e.setReadOnly(True)
        msg = _('Bitcoin SV address where the payment should be received. '
                'Note that each payment request uses a different Bitcoin SV address.')
        self.receive_address_label = HelpLabel(_('Receiving address'), msg)
        self.receive_address_e.textChanged.connect(self.update_receive_qr)
        self.receive_address_e.setFocusPolicy(Qt.NoFocus)
        grid.addWidget(self.receive_address_label, 0, 0)
        grid.addWidget(self.receive_address_e, 0, 1, 1, -1)

        self.receive_message_e = QLineEdit()
        grid.addWidget(QLabel(_('Description')), 1, 0)
        grid.addWidget(self.receive_message_e, 1, 1, 1, -1)
        self.receive_message_e.textChanged.connect(self.update_receive_qr)

        self.receive_amount_e = BTCAmountEdit()
        grid.addWidget(QLabel(_('Requested amount')), 2, 0)
        grid.addWidget(self.receive_amount_e, 2, 1)
        self.receive_amount_e.textChanged.connect(self.update_receive_qr)

        self.fiat_receive_e = AmountEdit(app_state.fx.get_currency if app_state.fx else '')
        if not app_state.fx or not app_state.fx.is_enabled():
            self.fiat_receive_e.setVisible(False)
        grid.addWidget(self.fiat_receive_e, 2, 2, Qt.AlignLeft)
        self.connect_fields(self, self.receive_amount_e, self.fiat_receive_e, None)

        self.expires_combo = QComboBox()
        self.expires_combo.addItems([i[0] for i in expiration_values])
        self.expires_combo.setCurrentIndex(3)
        self.expires_combo.setFixedWidth(self.receive_amount_e.width())
        msg = ' '.join([
            _('Expiration date of your request.'),
            _('This information is seen by the recipient if you send them '
              'a signed payment request.'),
            _('Expired requests have to be deleted manually from your list, '
              'in order to free the corresponding Bitcoin SV addresses.'),
            _('The Bitcoin SV address never expires and will always be part '
              'of this ElectrumSV wallet.'),
        ])
        grid.addWidget(HelpLabel(_('Request expires'), msg), 3, 0)
        grid.addWidget(self.expires_combo, 3, 1)
        self.expires_label = QLineEdit('')
        self.expires_label.setReadOnly(1)
        self.expires_label.setFocusPolicy(Qt.NoFocus)
        self.expires_label.hide()
        grid.addWidget(self.expires_label, 3, 1)

        self.save_request_button = QPushButton(_('Save'))
        self.save_request_button.clicked.connect(self.save_payment_request)

        self.new_request_button = QPushButton(_('New'))
        self.new_request_button.clicked.connect(self.new_payment_request)

        self.receive_qr = QRCodeWidget(fixedSize=200)
        self.receive_qr.mouseReleaseEvent = lambda x: self.toggle_qr_window()
        self.receive_qr.enterEvent = lambda x: self.app.setOverrideCursor(
            QCursor(Qt.PointingHandCursor))
        self.receive_qr.leaveEvent = lambda x: self.app.setOverrideCursor(QCursor(Qt.ArrowCursor))

        self.receive_buttons = buttons = QHBoxLayout()
        buttons.addStretch(1)
        buttons.addWidget(self.save_request_button)
        buttons.addWidget(self.new_request_button)
        grid.addLayout(buttons, 4, 1, 1, 2)

        self.receive_requests_label = QLabel(_('Requests'))

        from .request_list import RequestList
        self.request_list = RequestList(self)

        # layout
        vbox_g = QVBoxLayout()
        vbox_g.addLayout(grid)
        vbox_g.addStretch()

        hbox = QHBoxLayout()
        hbox.addLayout(vbox_g)
        hbox.addWidget(self.receive_qr)

        w = QWidget()
        w.searchable_list = self.request_list
        vbox = QVBoxLayout(w)
        vbox.addLayout(hbox)
        vbox.addStretch(1)
        vbox.addWidget(self.receive_requests_label)
        vbox.addWidget(self.request_list)
        vbox.setStretchFactor(self.request_list, 1000)

        return w


    def delete_payment_request(self, addr):
        self.wallet.remove_payment_request(addr, self.config)
        self.request_list.update()
        self.clear_receive_tab()

    def get_request_URI(self, addr):
        req = self.wallet.receive_requests[addr]
        message = self.wallet.labels.get(addr.to_string(), '')
        amount = req['amount']
        URI = web.create_URI(addr, amount, message)
        if req.get('time'):
            URI += "&time=%d"%req.get('time')
        if req.get('exp'):
            URI += "&exp=%d"%req.get('exp')
        if req.get('name') and req.get('sig'):
            sig = bfh(req.get('sig'))
            sig = bitcoin.base_encode(sig, base=58)
            URI += "&name=" + req['name'] + "&sig="+sig
        return str(URI)

    def sign_payment_request(self, addr):
        alias_privkey = None
        if app_state.alias_info:
            alias_addr, alias_name, validated = app_state.alias_info
            if alias_addr and self.wallet.is_mine(alias_addr):
                msg = '\n'.join([
                    _('This payment request will be signed.'),
                    _('Please enter your password')
                ])
                password = self.password_dialog(msg)
                if password:
                    alias = self.config.get('alias')
                    try:
                        self.wallet.sign_payment_request(addr, alias, alias_addr, password)
                    except Exception as e:
                        self.show_error(str(e))

    def save_payment_request(self):
        if not self.receive_address:
            self.show_error(_('No receiving address'))
        amount = self.receive_amount_e.get_amount()
        message = self.receive_message_e.text()
        if not message and not amount:
            self.show_error(_('No message or amount'))
            return False
        i = self.expires_combo.currentIndex()
        expiration = [x[1] for x in expiration_values][i]
        req = self.wallet.make_payment_request(self.receive_address, amount,
                                               message, expiration)
        self.wallet.add_payment_request(req, self.config)
        self.sign_payment_request(self.receive_address)
        self.request_list.update()
        self.address_list.update()
        self.save_request_button.setEnabled(False)

    def view_and_paste(self, title, msg, data):
        dialog = WindowModalDialog(self, title)
        vbox = QVBoxLayout()
        label = QLabel(msg)
        label.setWordWrap(True)
        vbox.addWidget(label)
        pr_e = ShowQRTextEdit(text=data)
        vbox.addWidget(pr_e)
        vbox.addLayout(Buttons(CopyCloseButton(pr_e.text, self.app, dialog)))
        dialog.setLayout(vbox)
        dialog.exec_()

    def export_payment_request(self, addr):
        r = self.wallet.receive_requests[addr]
        pr = paymentrequest.serialize_request(r).SerializeToString()
        name = r['id'] + '.bip70'
        fileName = self.getSaveFileName(_("Select where to save your payment request"),
                                        name, "*.bip70")
        if fileName:
            with open(fileName, "wb+") as f:
                f.write(util.to_bytes(pr))
            self.show_message(_("Request saved successfully"))
            self.saved = True

    def new_payment_request(self):
        addr = self.wallet.get_unused_address()
        if addr is None:
            if not self.wallet.is_deterministic():
                msg = [
                    _('No more addresses in your wallet.'),
                    _('You are using a non-deterministic wallet, which '
                      'cannot create new addresses.'),
                    _('If you want to create new addresses, use a deterministic wallet instead.')
                   ]
                self.show_message(' '.join(msg))
                return
            if not self.question(_(
                    'Warning: The next address will not be recovered automatically if '
                    'you restore your wallet from seed; you may need to add it manually.\n\n'
                    'This occurs because you have too many unused addresses in your wallet. '
                    'To avoid this situation, use the existing addresses first.\n\n'
                    'Create anyway?'
            )):
                return
            addr = self.wallet.create_new_address(False)
        self.set_receive_address(addr)
        self.expires_label.hide()
        self.expires_combo.show()
        self.new_request_button.setEnabled(False)
        self.receive_message_e.setFocus(1)

    def set_receive_address(self, addr):
        self.receive_address = addr
        self.receive_message_e.setText('')
        self.receive_amount_e.setAmount(None)
        self.update_receive_address_widget()

    def update_receive_address_widget(self):
        text = ''
        if self.receive_address:
            text = self.receive_address.to_string()
        self.receive_address_e.setText(text)

    def clear_receive_tab(self):
        self.expires_label.hide()
        self.expires_combo.show()
        self.set_receive_address(self.wallet.get_receiving_address())

    def toggle_qr_window(self):
        from . import qrwindow
        if not self.qr_window:
            self.qr_window = qrwindow.QR_Window(self)
            self.qr_window.setVisible(True)
            self.qr_window_geometry = self.qr_window.geometry()
        else:
            if not self.qr_window.isVisible():
                self.qr_window.setVisible(True)
                self.qr_window.setGeometry(self.qr_window_geometry)
            else:
                self.qr_window_geometry = self.qr_window.geometry()
                self.qr_window.setVisible(False)
        self.update_receive_qr()

    def show_send_tab(self):
        self.tabs.setCurrentIndex(self.tabs.indexOf(self.send_tab))

    def show_receive_tab(self):
        self.tabs.setCurrentIndex(self.tabs.indexOf(self.receive_tab))

    def receive_at(self, addr):
        self.receive_address = addr
        self.show_receive_tab()
        self.new_request_button.setEnabled(True)
        self.update_receive_address_widget()

    def update_receive_qr(self):
        amount = self.receive_amount_e.get_amount()
        message = self.receive_message_e.text()
        self.save_request_button.setEnabled((amount is not None) or (message != ""))
        uri = web.create_URI(self.receive_address, amount, message)
        self.receive_qr.setData(uri)
        if self.qr_window and self.qr_window.isVisible():
            self.qr_window.set_content(self.receive_address_e.text(), amount,
                                       message, uri)

    def create_send_tab(self):
        # A 4-column grid layout.  All the stretch is in the last column.
        # The exchange rate plugin adds a fiat widget in column 2
        self.send_grid = grid = QGridLayout()
        grid.setSpacing(8)
        # This ensures all columns are stretched over the full width of the last tab.
        grid.setColumnStretch(4, 1)

        from .paytoedit import PayToEdit
        self.amount_e = BTCAmountEdit()
        self.payto_e = PayToEdit(self)

        # From fields row.
        # This is enabled by "spending" coins in the coins tab.

        self.from_label = QLabel(_('From'))
        self.from_label.setContentsMargins(0, 5, 0, 0)
        self.from_label.setAlignment(Qt.AlignTop)
        grid.addWidget(self.from_label, 1, 0)
        self.from_list = MyTreeWidget(self, self.from_list_menu, ['Address / Outpoint','Amount'])
        self.from_list.setMaximumHeight(80)
        grid.addWidget(self.from_list, 1, 1, 1, -1)
        self.set_pay_from([])

        msg = (_('Recipient of the funds.') + '\n\n' +
               _('You may enter a Bitcoin SV address, a label from your list of '
                 'contacts (a list of completions will be proposed), or an alias '
                 '(email-like address that forwards to a Bitcoin SV address)'))
        payto_label = HelpLabel(_('Pay to'), msg)
        payto_label.setSizePolicy(QSizePolicy.Maximum, QSizePolicy.Preferred)
        grid.addWidget(payto_label, 2, 0)
        grid.addWidget(self.payto_e, 2, 1, 1, -1)

        msg = (_('Amount to be sent.') + '\n\n' +
               _('The amount will be displayed in red if you do not have '
                 'enough funds in your wallet.') + ' '
               + _('Note that if you have frozen some of your addresses, the available '
                   'funds will be lower than your total balance.') + '\n\n'
               + _('Keyboard shortcut: type "!" to send all your coins.'))
        amount_label = HelpLabel(_('Amount'), msg)
        grid.addWidget(amount_label, 3, 0)
        grid.addWidget(self.amount_e, 3, 1)

        self.fiat_send_e = AmountEdit(app_state.fx.get_currency if app_state.fx else '')
        if not app_state.fx or not app_state.fx.is_enabled():
            self.fiat_send_e.setVisible(False)
        grid.addWidget(self.fiat_send_e, 3, 2)
        self.amount_e.frozen.connect(
            lambda: self.fiat_send_e.setFrozen(self.amount_e.isReadOnly()))

        self.max_button = EnterButton(_("Max"), self.spend_max)
        self.max_button.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Preferred)
        grid.addWidget(self.max_button, 3, 3)

        completer = QCompleter()
        completer.setCaseSensitivity(False)
        self.payto_e.set_completer(completer)
        completer.setModel(self.completions)

        msg = (_('Description of the transaction (not mandatory).') + '\n\n' +
               _('The description is not sent to the recipient of the funds. '
                 'It is stored in your wallet file, and displayed in the \'History\' tab.'))
        description_label = HelpLabel(_('Description'), msg)
        grid.addWidget(description_label, 4, 0)
        self.message_e = MyLineEdit()
        grid.addWidget(self.message_e, 4, 1, 1, -1)

        # OP_RETURN fields row

        msg_attached = (_('Attached files (optional).') + '\n\n' +
                        _('Posts PERMANENT data to the Bitcoin SV blockchain as part of '
                          'this transaction using OP_RETURN.') + '\n\n' +
                        _('If you attach files, the \'Pay to\' field can be left blank.'))
        attached_data_label = HelpLabel(_('Attached Files'), msg_attached)
        attached_data_label.setContentsMargins(0, 5, 0, 0)
        attached_data_label.setAlignment(Qt.AlignTop)
        grid.addWidget(attached_data_label,  5, 0)

        hbox = QHBoxLayout()
        hbox.setSpacing(0)
        def attach_menu(*args):
            pass
        self.send_data_list = MyTreeWidget(self, attach_menu,
            [ "", _("File size"), _("File name"), "" ], 2)
        self.send_data_list.setSelectionMode(MyTreeWidget.SingleSelection)
        self.send_data_list.setSelectionBehavior(MyTreeWidget.SelectRows)
        hbox.addWidget(self.send_data_list)
        vbox = QVBoxLayout()
        vbox.setSpacing(0)
        vbox.setContentsMargins(5, 0, 0, 0)
        attach_button = EnterButton("", self._do_add_send_attachments)
        attach_button.setToolTip(_("Add file(s)"))
        attach_button.setIcon(read_QIcon("icons8-attach-96.png"))
        attach_button.setSizePolicy(QSizePolicy.Maximum, QSizePolicy.Maximum)
        vbox.addWidget(attach_button)
        vbox.addStretch()
        hbox.addLayout(vbox)
        self._on_send_data_list_updated()
        grid.addLayout(hbox, 5, 1, 1, -1)

        self.connect_fields(self, self.amount_e, self.fiat_send_e, None)

        self.preview_button = EnterButton(_("Preview"), self.do_preview)
        self.preview_button.setToolTip(
            _('Display the details of your transactions before signing it.'))
        self.send_button = EnterButton(_("Send"), self.do_send)
        if self.network is None:
            self.send_button.setEnabled(False)
            self.send_button.setToolTip(_('You are using ElectrumSV in offline mode; restart '
                                          'ElectrumSV if you want to get connected'))

        self.clear_button = EnterButton(_("Clear"), self.do_clear)

        buttons = QHBoxLayout()
        buttons.addStretch(1)
        buttons.addWidget(self.clear_button)
        buttons.addWidget(self.preview_button)
        buttons.addWidget(self.send_button)
        buttons.addStretch(1)
        grid.addLayout(buttons, 6, 0, 1, -1)

        self.amount_e.shortcut.connect(self.spend_max)
        self.payto_e.textChanged.connect(self.update_fee)
        self.amount_e.textEdited.connect(self.update_fee)

        def reset_max(t):
            self.is_max = False
            self.max_button.setEnabled(not bool(t))
        self.amount_e.textEdited.connect(reset_max)
        self.fiat_send_e.textEdited.connect(reset_max)

        def entry_changed():
            text = ""
            if self.not_enough_funds:
                amt_color = ColorScheme.RED
                text = _( "Not enough funds" )
                c, u, x = self.wallet.get_frozen_balance()
                if c+u+x:
                    text += (' (' + self.format_amount(c+u+x).strip() + ' ' +
                             app_state.base_unit() + ' ' + _("are frozen") + ')')

            if self.amount_e.isModified():
                amt_color = ColorScheme.DEFAULT
            else:
                amt_color = ColorScheme.BLUE

            self.statusBar().showMessage(text)
            self.amount_e.setStyleSheet(amt_color.as_stylesheet())

        self.amount_e.textChanged.connect(entry_changed)

        self.invoices_label = QLabel(_('Invoices'))
        from .invoice_list import InvoiceList
        self.invoice_list = InvoiceList(self)

        vbox0 = QVBoxLayout()
        vbox0.addLayout(grid)
        hbox = QHBoxLayout()
        hbox.addLayout(vbox0)
        w = QWidget()
        vbox = QVBoxLayout(w)
        vbox.addLayout(hbox)
        vbox.addStretch(1)
        vbox.addWidget(self.invoices_label)
        vbox.addWidget(self.invoice_list)
        vbox.setStretchFactor(self.invoice_list, 1000)
        w.searchable_list = self.invoice_list
        return w

    def spend_max(self):
        self.is_max = True
        self.do_update_fee()

    def update_fee(self):
        self.require_fee_update = True

    def get_payto_or_dummy(self):
        r = self.payto_e.get_recipient()
        if r:
            return r
        return (TYPE_ADDRESS, self.wallet.dummy_address())

    def get_custom_fee_text(self, fee_rate = None):
        if not self.config.has_custom_fee_rate():
            return ""
        else:
            if fee_rate is None: fee_rate = self.config.custom_fee_rate() / 1000.0
            return str(round(fee_rate*100)/100) + " sats/B"

    def get_opreturn_outputs(self, outputs):
        table = self.send_data_list

        file_paths = []
        for row_index in range(table.model().rowCount()):
            item = table.topLevelItem(row_index)
            file_paths.append(item.data(0, Qt.UserRole))
        if len(file_paths):
            data_chunks = []
            for file_path in file_paths:
                with open(file_path, "rb") as f:
                    data_chunks.append(f.read())
            amount = 0
            output_tuple = (TYPE_SCRIPT, ScriptOutput.as_op_return(data_chunks), amount)
            return [ output_tuple ]
        return []

    def do_update_fee(self):
        '''Recalculate the fee.  If the fee was manually input, retain it, but
        still build the TX to see if there are enough funds.
        '''
        amount = '!' if self.is_max else self.amount_e.get_amount()
        if amount is None:
            self.not_enough_funds = False
            self.statusBar().showMessage('')
        else:
            fee = None
            outputs = self.payto_e.get_outputs(self.is_max)
            if not outputs:
                _type, addr = self.get_payto_or_dummy()
                outputs = [(_type, addr, amount)]

            outputs.extend(self.get_opreturn_outputs(outputs))
            try:
                tx = self.wallet.make_unsigned_transaction(self.get_coins(), outputs,
                                                           self.config, fee)
                self.not_enough_funds = False
            except NotEnoughFunds:
                self.not_enough_funds = True
                return
            except Exception:
                return

            if self.is_max:
                amount = tx.output_value()
                self.amount_e.setAmount(amount)

    def from_list_delete(self, item):
        i = self.from_list.indexOfTopLevelItem(item)
        self.pay_from.pop(i)
        self.redraw_from_list()
        self.update_fee()

    def from_list_menu(self, position):
        item = self.from_list.itemAt(position)
        menu = QMenu()
        menu.addAction(_("Remove"), lambda: self.from_list_delete(item))
        menu.exec_(self.from_list.viewport().mapToGlobal(position))

    def set_pay_from(self, coins):
        self.pay_from = list(coins)
        self.redraw_from_list()

    def redraw_from_list(self):
        self.from_list.clear()
        self.from_label.setHidden(len(self.pay_from) == 0)
        self.from_list.setHidden(len(self.pay_from) == 0)

        def format(x):
            h = x['prevout_hash']
            return '{}...{}:{:d}\t{}'.format(h[0:10], h[-10:],
                                             x['prevout_n'], x['address'])

        for item in self.pay_from:
            self.from_list.addTopLevelItem(QTreeWidgetItem(
                [format(item), self.format_amount(item['value']) ]))

        update_fixed_tree_height(self.from_list)

    def get_contact_payto(self, key):
        _type, label = self.contacts.get(key)
        return label + '  <' + key + '>' if _type == 'address' else key

    def update_completions(self):
        l = [self.get_contact_payto(key) for key in self.contacts.keys()]
        self.completions.setStringList(l)

    def protected(func): # pylint: disable=no-self-argument
        '''Password request wrapper.  The password is passed to the function
        as the 'password' named argument.  "None" indicates either an
        unencrypted wallet, or the user cancelled the password request.
        An empty input is passed as the empty string.'''
        def request_password(self, *args, **kwargs):
            parent = self.top_level_window()
            password = None
            while self.wallet.has_password():
                password = self.password_dialog(parent=parent)
                if password is None:
                    # User cancelled password input
                    return
                try:
                    self.wallet.check_password(password)
                    break
                except Exception as e:
                    self.show_error(str(e), parent=parent)
                    continue

            kwargs['password'] = password
            return func(self, *args, **kwargs)
        return request_password

    def read_send_tab(self):
        isInvoice= False

        if self.payment_request and self.payment_request.has_expired():
            self.show_error(_('Payment request has expired'))
            return
        label = self.message_e.text()

        if self.payment_request:
            isInvoice = True
            outputs = self.payment_request.get_outputs()
        else:
            errors = self.payto_e.get_errors()
            if errors:
                self.show_warning(_("Invalid lines found:") + "\n\n" +
                                  '\n'.join([ _("Line #") + str(x[0]+1) + ": " + x[1]
                                              for x in errors]))
                return
            outputs = self.payto_e.get_outputs(self.is_max)

            if self.payto_e.is_alias and self.payto_e.validated is False:
                alias = self.payto_e.toPlainText()
                msg = _('WARNING: the alias "{}" could not be validated via an additional '
                        'security check, DNSSEC, and thus may not be correct.\n').format(alias)
                msg += _('Do you wish to continue?')
                if not self.question(msg):
                    return

        outputs.extend(self.get_opreturn_outputs(outputs))

        if not outputs:
            self.show_error(_('No outputs'))
            return

        for _type, addr, amount in outputs:
            if amount is None:
                self.show_error(_('Invalid Amount'))
                return
        fee = None
        coins = self.get_coins(isInvoice)
        return outputs, fee, label, coins

    def _on_send_data_list_updated(self):
        item_count = self.send_data_list.model().rowCount()

        is_enabled = item_count > 0
        self.send_data_list.setEnabled(is_enabled)
        self.send_data_list.setToolTip(_("Attach a file to include it in the transaction."))
        update_fixed_tree_height(self.send_data_list, maximum_height=80)

    def _do_add_send_attachments(self):
        dialogs.show_named('illegal-files-are-traceable')

        table = self.send_data_list
        file_paths = self.getOpenFileNames(_("Select file(s)"))
        last_item = None
        for file_path in file_paths:
            file_name = os.path.basename(file_path)
            file_size = os.path.getsize(file_path)
            item = QTreeWidgetItem()
            item.setData(0, Qt.UserRole, file_path)
            item.setIcon(0, read_QIcon("icons8-file-512.png"))
            item.setText(1, str(file_size))
            item.setTextAlignment(1, Qt.AlignRight | Qt.AlignVCenter)
            item.setText(2, file_name)

            table.addChild(item)

            # Setting item column widgets only works when the item is added to the table.
            delete_button = QPushButton()
            delete_button.clicked.connect(partial(self._on_delete_attachment, file_path))
            delete_button.setFlat(True)
            delete_button.setCursor(QCursor(Qt.PointingHandCursor))
            delete_button.setIcon(read_QIcon("icons8-trash.svg"))
            table.setItemWidget(item, 3, delete_button)

            last_item = item

        if last_item is not None:
            self._on_send_data_list_updated()
            table.scrollToItem(last_item)

    def _on_delete_attachment(self, file_path, checked=False):
        table = self.send_data_list
        for row_index in range(table.model().rowCount()):
            item = table.topLevelItem(row_index)
            item_file_path = item.data(0, Qt.UserRole)
            if item_file_path == file_path:
                table.takeTopLevelItem(row_index)
                break

    def do_preview(self):
        self.do_send(preview = True)

    def do_send(self, preview = False):
        r = self.read_send_tab()
        if not r:
            return
        outputs, fee, tx_desc, coins = r
        try:
            tx = self.wallet.make_unsigned_transaction(coins, outputs, self.config, fee)
        except NotEnoughFunds:
            self.show_message(_("Insufficient funds"))
            return
        except ExcessiveFee:
            self.show_message(_("Your fee is too high.  Max is 50 sat/byte."))
            return
        except Exception as e:
            self.logger.exception("")
            self.show_message(str(e))
            return

        amount = tx.output_value() if self.is_max else sum(x[2] for x in outputs)
        fee = tx.get_fee()

        if preview:
            self.show_transaction(tx, tx_desc)
            return

        # confirmation dialog
        msg = [
            _("Amount to be sent") + ": " + self.format_amount_and_units(amount),
            _("Mining fee") + ": " + self.format_amount_and_units(fee),
        ]

        confirm_rate = 2 * self.config.max_fee_rate()

        if fee < (tx.estimated_size()):
            msg.append(_('Warning') + ': ' +
                       _('The fee is less than 1000 sats/kb.  '
                         'It may take a very long time to confirm.'))

        if self.wallet.has_password():
            msg.append("")
            msg.append(_("Enter your password to proceed"))
            password = self.password_dialog('\n'.join(msg))
            if not password:
                return
        else:
            msg.append(_('Proceed?'))
            password = None
            if not self.question('\n'.join(msg)):
                return

        def sign_done(success):
            if success:
                if not tx.is_complete():
                    self.show_transaction(tx)
                    self.do_clear()
                else:
                    self.broadcast_transaction(tx, tx_desc)
        self.sign_tx_with_password(tx, sign_done, password)

    @protected
    def sign_tx(self, tx, callback, password, window=None):
        self.sign_tx_with_password(tx, callback, password, window=window)

    def sign_tx_with_password(self, tx, callback, password, window=None):
        '''Sign the transaction in a separate thread.  When done, calls
        the callback with a success code of True or False.
        '''
        def on_done(future):
            try:
                future.result()
            except Exception as exc:
                self.on_exception(exc)
                callback(False)
            else:
                callback(True)

        def sign_tx():
            if self.tx_external_keypairs:
                tx.sign(self.tx_external_keypairs)
            else:
                self.wallet.sign_transaction(tx, password)

        window = window or self
        WaitingDialog(window, _('Signing transaction...'), sign_tx, on_done=on_done)

    def broadcast_transaction(self, tx, tx_desc, success_text=None, window=None):
        if success_text is None:
            success_text = _('Payment sent.')
        window = window or self

        def broadcast_tx():
            # non-GUI thread
            status = False
            msg = "Failed"
            pr = self.payment_request
            if pr:
                if pr.has_expired():
                    self.payment_request = None
                    raise Exception(_("Payment request has expired"))
                refund_address = self.wallet.get_receiving_addresses()[0]
                ack_status, ack_msg = pr.send_payment(str(tx), refund_address)
                msg = ack_msg
                if ack_status:
                    self.invoices.set_paid(pr, tx.txid())
                    self.invoices.save()
                    self.payment_request = None
                return None
            else:
                return self.network.broadcast_transaction_and_wait(tx)

        def on_done(future):
            # GUI thread
            try:
                tx_id = future.result()
            except Exception as exception:
                self.logger.info(f'raw server error (untrusted): {exception}')
                reason = broadcast_failure_reason(exception)
                d = UntrustedMessageDialog(
                    window, _("Transaction Broadcast Error"),
                    _("Your transaction was not sent: ") + reason + ".",
                    exception)
                d.exec()
            else:
                if tx_id:
                    if tx_desc is not None and tx.is_complete():
                        self.wallet.set_label(tx.txid(), tx_desc)
                    window.show_message(success_text + '\n' + tx_id)
                    self.invoice_list.update()
                    self.do_clear()

        WaitingDialog(window, _('Broadcasting transaction...'), broadcast_tx, on_done=on_done)

    def query_choice(self, msg, choices):
        # Needed by QtHandler for hardware wallets
        dialog = WindowModalDialog(self.top_level_window())
        clayout = ChoicesLayout(msg, choices)
        vbox = QVBoxLayout(dialog)
        vbox.addLayout(clayout.layout())
        vbox.addLayout(Buttons(OkButton(dialog)))
        if not dialog.exec_():
            return None
        return clayout.selected_index()

    def lock_amount(self, b):
        self.amount_e.setFrozen(b)
        self.max_button.setEnabled(not b)

    def prepare_for_payment_request(self):
        self.show_send_tab()
        self.payto_e.is_pr = True
        for e in [self.payto_e, self.amount_e, self.message_e]:
            e.setFrozen(True)
        self.max_button.setDisabled(True)
        self.payto_e.setText(_("please wait..."))
        return True

    def delete_invoice(self, key):
        self.invoices.remove(key)
        self.invoice_list.update()

    def payment_request_ok(self):
        pr = self.payment_request
        key = self.invoices.add(pr)
        status = self.invoices.get_status(key)
        self.invoice_list.update()
        if status == PR_PAID:
            self.show_message("invoice already paid")
            self.do_clear()
            self.payment_request = None
            return
        self.payto_e.is_pr = True
        if not pr.has_expired():
            self.payto_e.set_validated()
        else:
            self.payto_e.set_expired()
        self.payto_e.setText(pr.get_requestor())
        self.amount_e.setText(format_satoshis_plain(pr.get_amount(), app_state.decimal_point))
        self.message_e.setText(pr.get_memo())
        # signal to set fee
        self.amount_e.textEdited.emit("")

    def payment_request_error(self):
        self.show_message(self.payment_request.error)
        self.payment_request = None
        self.do_clear()

    def on_pr(self, request):
        self.payment_request = request
        if self.payment_request.verify(self.contacts):
            self.payment_request_ok_signal.emit()
        else:
            self.payment_request_error_signal.emit()

    def pay_to_URI(self, URI):
        if not URI:
            return
        try:
            out = web.parse_URI(URI, self.on_pr)
        except Exception as e:
            self.show_error(str(e))
            return
        self.show_send_tab()
        r = out.get('r')
        sig = out.get('sig')
        name = out.get('name')
        if r or (name and sig):
            self.prepare_for_payment_request()
            return
        address = out.get('address')
        amount = out.get('amount')
        label = out.get('label')
        message = out.get('message')
        # use label as description (not BIP21 compliant)
        if label and not message:
            message = label
        if address:
            self.payto_e.setText(address)
        if message:
            self.message_e.setText(message)
        if amount:
            self.amount_e.setAmount(amount)
            self.amount_e.textEdited.emit("")

    def do_clear(self):
        self.is_max = False
        self.not_enough_funds = False
        self.payment_request = None
        self.payto_e.is_pr = False

        edit_fields = []
        edit_fields.extend(self.send_tab.findChildren(QPlainTextEdit))
        edit_fields.extend(self.send_tab.findChildren(QLineEdit))
        for edit_field in edit_fields:
            edit_field.setText('')
            edit_field.setFrozen(False)

        for tree in self.send_tab.findChildren(QTreeView):
            tree.clear()
        self._on_send_data_list_updated()

        self.max_button.setDisabled(False)
        self.set_pay_from([])
        self.tx_external_keypairs = {}
        self.update_status()

    def set_frozen_state(self, addrs, freeze):
        self.wallet.set_frozen_state(addrs, freeze)
        self.address_list.update()
        self.utxo_list.update()
        self.update_fee()

    def set_frozen_coin_state(self, utxos, freeze):
        self.wallet.set_frozen_coin_state(utxos, freeze)
        self.utxo_list.update()
        self.update_fee()

    def create_coinsplitting_tab(self):
        return CoinSplittingTab(self)

    def create_list_tab(self, l, list_header=None):
        w = QWidget()
        w.searchable_list = l
        vbox = QVBoxLayout()
        w.setLayout(vbox)
        vbox.setContentsMargins(0, 0, 0, 0)
        vbox.setSpacing(0)
        if list_header:
            hbox = QHBoxLayout()
            for b in list_header:
                hbox.addWidget(b)
            hbox.addStretch()
            vbox.addLayout(hbox)
        vbox.addWidget(l)
        return w

    def create_addresses_tab(self):
        from .address_list import AddressList
        self.address_list = l = AddressList(self)
        return self.create_list_tab(l)

    def create_utxo_tab(self):
        from .utxo_list import UTXOList
        self.utxo_list = l = UTXOList(self)
        return self.create_list_tab(l)

    def create_contacts_tab(self):
        from .contact_list import ContactList
        self.contact_list = l = ContactList(self)
        return self.create_list_tab(l)

    def remove_address(self, addr):
        if self.question(_("Do you want to remove {} from your wallet?"
                           .format(addr.to_string()))):
            self.wallet.delete_address(addr)
            self.address_list.update()
            self.history_list.update()
            self.history_updated_signal.emit()
            self.clear_receive_tab()

    def get_coins(self, isInvoice = False):
        if self.pay_from:
            return self.pay_from
        else:
            return self.wallet.get_spendable_coins(None, self.config, isInvoice)

    def spend_coins(self, coins):
        self.set_pay_from(coins)
        self.show_send_tab()
        self.update_fee()

    def paytomany(self):
        self.show_send_tab()
        self.payto_e.paytomany()
        msg = '\n'.join([
            _('Enter a list of outputs in the \'Pay to\' field.'),
            _('One output per line.'),
            _('Format: address, amount'),
            _('You may load a CSV file using the file icon.')
        ])
        self.show_message(msg, title=_('Pay to many'))

    def payto_contacts(self, labels):
        paytos = [self.get_contact_payto(label) for label in labels]
        self.show_send_tab()
        if len(paytos) == 1:
            self.payto_e.setText(paytos[0])
            self.amount_e.setFocus()
        else:
            text = "\n".join([payto + ", 0" for payto in paytos])
            self.payto_e.setText(text)
            self.payto_e.setFocus()

    def set_contact(self, label, address):
        if not Address.is_valid(address):
            self.show_error(_('Invalid Address'))
            self.contact_list.update()  # Displays original unchanged value
            return False
        old_entry = self.contacts.get(address, None)
        self.contacts[address] = ('address', label)
        self.contact_list.update()
        self.history_list.update()
        self.history_updated_signal.emit()
        self.update_completions()
        return True

    def delete_contacts(self, addresses):
        if not self.question(_("Remove {} from your list of contacts?")
                             .format(" + ".join(addresses))):
            return
        removed_entries = []
        for address in addresses:
            if address in self.contacts.keys():
                removed_entries.append((address, self.contacts[address]))
            self.contacts.pop(address)

        self.history_list.update()
        self.history_updated_signal.emit()
        self.contact_list.update()
        self.update_completions()

    def show_invoice(self, key):
        pr = self.invoices.get(key)
        pr.verify(self.contacts)
        self.show_pr_details(pr)

    def show_pr_details(self, pr):
        key = pr.get_id()
        d = WindowModalDialog(self, _("Invoice"))
        vbox = QVBoxLayout(d)
        grid = QGridLayout()
        grid.addWidget(QLabel(_("Requestor") + ':'), 0, 0)
        grid.addWidget(QLabel(pr.get_requestor()), 0, 1)
        grid.addWidget(QLabel(_("Amount") + ':'), 1, 0)
        outputs_str = '\n'.join(self.format_amount(x[2]) + app_state.base_unit() +
                                ' @ ' + x[1].to_string()
                                for x in pr.get_outputs())
        grid.addWidget(QLabel(outputs_str), 1, 1)
        expires = pr.get_expiration_date()
        grid.addWidget(QLabel(_("Memo") + ':'), 2, 0)
        grid.addWidget(QLabel(pr.get_memo()), 2, 1)
        grid.addWidget(QLabel(_("Signature") + ':'), 3, 0)
        grid.addWidget(QLabel(pr.get_verify_status()), 3, 1)
        if expires:
            grid.addWidget(QLabel(_("Expires") + ':'), 4, 0)
            grid.addWidget(QLabel(format_time(expires, _("Unknown"))), 4, 1)
        vbox.addLayout(grid)
        def do_export():
            fn = self.getSaveFileName(_("Save invoice to file"), "*.bip70")
            if not fn:
                return
            with open(fn, 'wb') as f:
                data = f.write(pr.raw)
            self.show_message(_('Invoice saved as' + ' ' + fn))
        exportButton = EnterButton(_('Save'), do_export)
        def do_delete():
            if self.question(_('Delete invoice?')):
                self.invoices.remove(key)
                self.history_list.update()
                self.history_updated_signal.emit()
                self.invoice_list.update()
                d.close()
        deleteButton = EnterButton(_('Delete'), do_delete)
        vbox.addLayout(Buttons(exportButton, deleteButton, CloseButton(d)))
        d.exec_()

    def do_pay_invoice(self, key):
        pr = self.invoices.get(key)
        self.payment_request = pr
        self.prepare_for_payment_request()
        pr.error = None  # this forces verify() to re-run
        if pr.verify(self.contacts):
            self.payment_request_ok()
        else:
            self.payment_request_error()

    def create_console_tab(self):
        from .console import Console
        self.console = console = Console()
        return console

    def update_console(self):
        console = self.console
        console.history = self.config.get("console-history",[])
        console.history_index = len(console.history)

        console.updateNamespace({
            'app': self.app,
            'config': app_state.config,
            'daemon': app_state.daemon,
            'electrumsv': electrumsv,
            'network': self.network,
            'util': util,
            'wallet': self.wallet,
            'window': self,
        })

        c = commands.Commands(self.config, self.wallet, self.network,
                              lambda: self.console.set_json(True))
        methods = {}
        def mkfunc(f, method):
            return lambda *args, **kwargs: f(method, *args, password_getter=self.password_dialog,
                                             **kwargs)
        for m in dir(c):
            if m[0] == '_' or m in ['network', 'wallet', 'config']:
                continue
            methods[m] = mkfunc(c._run, m)

        console.updateNamespace(methods)

    def create_status_bar(self):
        sb = QStatusBar()

        balance_widget = QWidget()
        balance_icon_label = QLabel("")
        balance_icon_label.setPixmap(QPixmap(icon_path("sb_balance.png")))
        hbox = QHBoxLayout()
        hbox.setSpacing(2)
        hbox.addWidget(balance_icon_label)
        self.balance_bsv_label = QLabel("")
        hbox.addWidget(self.balance_bsv_label)
        self.balance_equals_label = QLabel("")
        self.balance_equals_label.setPixmap(QPixmap(icon_path("sb_approximate")))
        hbox.addWidget(self.balance_equals_label)
        self.balance_fiat_label = QLabel("")
        sp = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        sp.setHorizontalStretch(1)
        self.balance_fiat_label.setSizePolicy(sp)
        hbox.addWidget(self.balance_fiat_label)
        balance_widget.setLayout(hbox)
        sb.addPermanentWidget(balance_widget)

        self.set_status_bar_balance(None)

        self.fiat_widget = QWidget()
        self.fiat_widget.setVisible(False)
        estimate_icon_label = QLabel("")
        estimate_icon_label.setPixmap(QPixmap(icon_path("sb_fiat.png")))
        hbox = QHBoxLayout()
        hbox.setSpacing(2)
        hbox.addWidget(estimate_icon_label)
        self.fiat_bsv_label = QLabel("")
        hbox.addWidget(self.fiat_bsv_label)
        approximate_icon_label = QLabel("")
        approximate_icon_label.setPixmap(QPixmap(icon_path("sb_approximate")))
        hbox.addWidget(approximate_icon_label)
        self.fiat_value_label = QLabel("")
        sp = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        sp.setHorizontalStretch(1)
        self.fiat_value_label.setSizePolicy(sp)
        fm = self.fiat_bsv_label.fontMetrics()
        width = fm.width("1,000.00 CUR")
        self.fiat_value_label.setMinimumWidth(width)
        hbox.addWidget(self.fiat_value_label)
        self.fiat_widget.setLayout(hbox)
        sb.addPermanentWidget(self.fiat_widget)

        network_widget = QWidget()
        network_icon_label = QLabel("")
        network_icon_label.setPixmap(QPixmap(icon_path("sb_network.png")))
        hbox = QHBoxLayout()
        hbox.setSpacing(2)
        hbox.addWidget(network_icon_label)
        self.network_label = QLabel("")
        sp = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        sp.setHorizontalStretch(1)
        self.network_label.setSizePolicy(sp)
        hbox.addWidget(self.network_label)
        network_widget.setLayout(hbox)
        network_widget.setMinimumWidth(150)
        sb.addPermanentWidget(network_widget)

        self.search_box = QLineEdit()
        self.search_box.textChanged.connect(self.do_search)
        self.search_box.hide()
        sb.addPermanentWidget(self.search_box)

        self.setStatusBar(sb)

    def set_status_bar_balance(self, status):
        if not status or not status[0]:
            self.balance_bsv_label.setText(_("Unknown"))
            self.balance_equals_label.setVisible(False)
            self.balance_fiat_label.setVisible(False)
        else:
            self.balance_bsv_label.setText(status[0])
            if status[1]:
                self.balance_equals_label.setVisible(True)
                self.balance_fiat_label.setVisible(True)
                self.balance_fiat_label.setText(status[1])

    def set_status_bar_fiat(self, status):
        if status is None:
            self.fiat_widget.setVisible(False)
        else:
            self.fiat_widget.setVisible(True)
            self.fiat_bsv_label.setText(_("Unavailable") if status is None else status[0])
            self.fiat_value_label.setText(_("Unavailable") if status is None else status[1])

    def update_buttons_on_seed(self):
        self.send_button.setVisible(not self.wallet.is_watching_only())

    def change_password_dialog(self):
        from .password_dialog import ChangePasswordDialog
        d = ChangePasswordDialog(self, self.wallet)
        ok, password, new_password, encrypt_file = d.run()
        if not ok:
            return
        try:
            self.wallet.update_password(password, new_password, encrypt_file)
        except Exception as e:
            self.show_error(str(e))
            return
        except:
            self.logger.exception("")
            self.show_error(_('Failed to update password'))
            return
        msg = (_('Password was updated successfully') if new_password
               else _('Password is disabled, this wallet is not protected'))
        self.show_message(msg, title=_("Success"))

    def toggle_search(self):
        self.search_box.setHidden(not self.search_box.isHidden())
        if not self.search_box.isHidden():
            self.search_box.setFocus(1)
        else:
            self.do_search('')

    def do_search(self, t):
        tab = self.tabs.currentWidget()
        if hasattr(tab, 'searchable_list'):
            tab.searchable_list.filter(t)

    def new_contact_dialog(self):
        d = WindowModalDialog(self, _("New Contact"))
        vbox = QVBoxLayout(d)
        vbox.addWidget(QLabel(_('New Contact') + ':'))
        grid = QGridLayout()
        line1 = QLineEdit()
        line1.setFixedWidth(280)
        line2 = QLineEdit()
        line2.setFixedWidth(280)
        grid.addWidget(QLabel(_("Address")), 1, 0)
        grid.addWidget(line1, 1, 1)
        grid.addWidget(QLabel(_("Name")), 2, 0)
        grid.addWidget(line2, 2, 1)
        vbox.addLayout(grid)
        vbox.addLayout(Buttons(CancelButton(d), OkButton(d)))
        if d.exec_():
            self.set_contact(line2.text(), line1.text())

    def show_master_public_keys(self):
        dialog = QDialog(self)
        dialog.setWindowTitle(_("Wallet Information"))
        dialog.setMinimumSize(500, 100)
        mpk_list = self.wallet.get_master_public_keys()
        vbox = QVBoxLayout()
        wallet_type = self.wallet.storage.get('wallet_type', '')
        grid = QGridLayout()
        basename = os.path.basename(self.wallet.storage.path)
        grid.addWidget(QLabel(_("Wallet name")+ ':'), 0, 0)
        grid.addWidget(QLabel(basename), 0, 1)
        grid.addWidget(QLabel(_("Wallet type")+ ':'), 1, 0)
        grid.addWidget(QLabel(wallet_type), 1, 1)
        grid.addWidget(QLabel(_("Script type")+ ':'), 2, 0)
        grid.addWidget(QLabel(self.wallet.txin_type), 2, 1)
        vbox.addLayout(grid)
        if self.wallet.is_deterministic():
            mpk_text = ShowQRTextEdit()
            mpk_text.setMaximumHeight(150)
            mpk_text.addCopyButton(self.app)
            def show_mpk(index):
                mpk_text.setText(mpk_list[index])
            # only show the combobox in case multiple accounts are available
            if len(mpk_list) > 1:
                def label(key):
                    if isinstance(self.wallet, Multisig_Wallet):
                        return _("cosigner") + ' ' + str(key+1)
                    return ''
                labels = [label(i) for i in range(len(mpk_list))]
                on_click = lambda clayout: show_mpk(clayout.selected_index())
                labels_clayout = ChoicesLayout(_("Master Public Keys"), labels, on_click)
                vbox.addLayout(labels_clayout.layout())
            else:
                vbox.addWidget(QLabel(_("Master Public Key")))
            show_mpk(0)
            vbox.addWidget(mpk_text)
        vbox.addStretch(1)
        vbox.addLayout(Buttons(CloseButton(dialog)))
        dialog.setLayout(vbox)
        dialog.exec_()

    def remove_wallet(self):
        if self.question('\n'.join([
                _('Delete wallet file?'),
                "%s"%self.wallet.storage.path,
                _('If your wallet contains funds, make sure you have saved its seed.')])):
            self._delete_wallet() # pylint: disable=no-value-for-parameter

    @protected
    def _delete_wallet(self, password):
        wallet_path = self.wallet.storage.path
        basename = os.path.basename(wallet_path)
        app_state.daemon.stop_wallet_at_path(wallet_path)
        self.close()
        os.unlink(wallet_path)
        self.update_recently_visited(wallet_path) # this ensures it's deleted from the menu
        self.show_error("Wallet removed:" + basename)

    @protected
    def show_seed_dialog(self, password):
        if not self.wallet.has_seed():
            self.show_message(_('This wallet has no seed'))
            return
        keystore = self.wallet.get_keystore()
        try:
            seed = keystore.get_seed(password)
            passphrase = keystore.get_passphrase(password)
        except Exception as e:
            self.show_error(str(e))
            return
        from .seed_dialog import SeedDialog
        d = SeedDialog(self, seed, passphrase)
        d.exec_()

    def show_qrcode(self, data, title = _("QR code"), parent=None):
        if not data:
            return
        d = QRDialog(data, parent or self, title)
        d.exec_()

    @protected
    def show_private_key(self, address, password):
        if not address:
            return
        try:
            pk = self.wallet.export_private_key(address, password)
        except Exception as e:
            self.logger.exception("")
            self.show_message(str(e))
            return
        xtype = bitcoin.deserialize_privkey(pk)[0]
        d = WindowModalDialog(self, _("Private key"))
        d.setMinimumSize(600, 150)
        vbox = QVBoxLayout()
        vbox.addWidget(QLabel('{}: {}'.format(_("Address"), address)))
        vbox.addWidget(QLabel(_("Script type") + ': ' + xtype))
        vbox.addWidget(QLabel(_("Private key") + ':'))
        keys_e = ShowQRTextEdit(text=pk)
        keys_e.addCopyButton(self.app)
        vbox.addWidget(keys_e)
        vbox.addWidget(QLabel(_("Redeem Script") + ':'))
        rds_e = ShowQRTextEdit(text=address.to_script().hex())
        rds_e.addCopyButton(self.app)
        vbox.addWidget(rds_e)
        vbox.addLayout(Buttons(CloseButton(d)))
        d.setLayout(vbox)
        d.exec_()

    msg_sign = _("Signing with an address actually means signing with the corresponding "
                "private key, and verifying with the corresponding public key. The "
                "address you have entered does not have a unique public key, so these "
                "operations cannot be performed.") + '\n\n' + \
               _('The operation is undefined. Not just in ElectrumSV, but in general.')

    @protected
    def do_sign(self, address, message, signature, password):
        address  = address.text().strip()
        message = message.toPlainText().strip()
        try:
            addr = Address.from_string(address)
        except:
            self.show_message(_('Invalid Bitcoin SV address.'))
            return
        if addr.kind != addr.ADDR_P2PKH:
            self.show_message(_('Cannot sign messages with this type of address.') + '\n\n' +
                              self.msg_sign)
        if self.wallet.is_watching_only():
            self.show_message(_('This is a watching-only wallet.'))
            return
        if not self.wallet.is_mine(addr):
            self.show_message(_('Address not in wallet.'))
            return

        def show_signed_message(sig):
            signature.setText(base64.b64encode(sig).decode('ascii'))
        self.run_in_thread(self.wallet.sign_message, addr, message, password,
                           on_success=show_signed_message)

    def run_in_thread(self, func, *args, on_success=None):
        def _on_done(future):
            try:
                result = future.result()
            except Exception as exc:
                self.on_exception(exc)
            else:
                if on_success:
                    on_success(result)
        return self.app.run_in_thread(func, *args, on_done=_on_done)

    def do_verify(self, address, message, signature):
        try:
            address = Address.from_string(address.text().strip())
        except:
            self.show_message(_('Invalid Bitcoin SV address.'))
            return
        message = message.toPlainText().strip().encode('utf-8')
        try:
            # This can throw on invalid base64
            sig = base64.b64decode(signature.toPlainText())
            verified = ecc.verify_message_with_address(address, sig, message)
        except:
            verified = False

        if verified:
            self.show_message(_("Signature verified"))
        else:
            self.show_error(_("Wrong signature"))

    def sign_verify_message(self, address=None):
        d = WindowModalDialog(self, _('Sign/verify Message'))
        d.setMinimumSize(610, 290)

        layout = QGridLayout(d)

        message_e = QTextEdit()
        message_e.setAcceptRichText(False)
        layout.addWidget(QLabel(_('Message')), 1, 0)
        layout.addWidget(message_e, 1, 1)
        layout.setRowStretch(2,3)

        address_e = QLineEdit()
        address_e.setText(address.to_string() if address else '')
        layout.addWidget(QLabel(_('Address')), 2, 0)
        layout.addWidget(address_e, 2, 1)

        signature_e = QTextEdit()
        signature_e.setAcceptRichText(False)
        layout.addWidget(QLabel(_('Signature')), 3, 0)
        layout.addWidget(signature_e, 3, 1)
        layout.setRowStretch(3,1)

        hbox = QHBoxLayout()

        b = QPushButton(_("Sign"))
        def do_sign(checked=False):
            # pylint: disable=no-value-for-parameter
            self.do_sign(address_e, message_e, signature_e)
        b.clicked.connect(do_sign)
        hbox.addWidget(b)

        b = QPushButton(_("Verify"))
        b.clicked.connect(partial(self.do_verify, address_e, message_e, signature_e))
        hbox.addWidget(b)

        b = QPushButton(_("Close"))
        b.clicked.connect(d.accept)
        hbox.addWidget(b)
        layout.addLayout(hbox, 4, 1)
        d.exec_()

    @protected
    def do_decrypt(self, message_e, pubkey_e, encrypted_e, password):
        if self.wallet.is_watching_only():
            self.show_message(_('This is a watching-only wallet.'))
            return
        cyphertext = encrypted_e.toPlainText()

        def show_decrypted_message(msg):
            message_e.setText(msg.decode())
        self.run_in_thread(self.wallet.decrypt_message, pubkey_e.text(), cyphertext, password,
                           on_success=show_decrypted_message)

    def do_encrypt(self, message_e, pubkey_e, encrypted_e):
        message = message_e.toPlainText()
        message = message.encode('utf-8')
        try:
            public_key = ecc.ECPubkey(bfh(pubkey_e.text()))
        except Exception as e:
            self.logger.exception("")
            self.show_warning(_('Invalid Public key'))
        else:
            encrypted = public_key.encrypt_message(message)
            encrypted_e.setText(encrypted.decode('ascii'))

    def encrypt_message(self, address=None):
        d = WindowModalDialog(self, _('Encrypt/decrypt Message'))
        d.setMinimumSize(610, 490)

        layout = QGridLayout(d)

        message_e = QTextEdit()
        message_e.setAcceptRichText(False)
        layout.addWidget(QLabel(_('Message')), 1, 0)
        layout.addWidget(message_e, 1, 1)
        layout.setRowStretch(2,3)

        pubkey_e = QLineEdit()
        if address:
            pubkey = self.wallet.get_public_key(address)
            if not isinstance(pubkey, str):
                pubkey = pubkey.to_string()
            pubkey_e.setText(pubkey)
        layout.addWidget(QLabel(_('Public key')), 2, 0)
        layout.addWidget(pubkey_e, 2, 1)

        encrypted_e = QTextEdit()
        encrypted_e.setAcceptRichText(False)
        layout.addWidget(QLabel(_('Encrypted')), 3, 0)
        layout.addWidget(encrypted_e, 3, 1)
        layout.setRowStretch(3,1)

        hbox = QHBoxLayout()
        b = QPushButton(_("Encrypt"))
        b.clicked.connect(lambda: self.do_encrypt(message_e, pubkey_e, encrypted_e))
        hbox.addWidget(b)

        b = QPushButton(_("Decrypt"))
        def do_decrypt(checked=False):
            # pylint: disable=no-value-for-parameter
            self.do_decrypt(message_e, pubkey_e, encrypted_e)
        b.clicked.connect(do_decrypt)
        hbox.addWidget(b)

        b = QPushButton(_("Close"))
        b.clicked.connect(d.accept)
        hbox.addWidget(b)

        layout.addLayout(hbox, 4, 1)
        d.exec_()

    def password_dialog(self, msg=None, parent=None):
        from .password_dialog import PasswordDialog
        parent = parent or self
        d = PasswordDialog(parent, msg)
        return d.run()

    def tx_from_text(self, txt):
        if not txt:
            return None
        txt_tx = tx_from_str(txt)
        tx = Transaction(txt_tx)
        tx.deserialize()
        if self.wallet:
            my_coins = self.wallet.get_spendable_coins(None, self.config)
            my_outpoints = [vin['prevout_hash'] + ':' + str(vin['prevout_n'])
                            for vin in my_coins]
            for i, txin in enumerate(tx.inputs()):
                outpoint = txin['prevout_hash'] + ':' + str(txin['prevout_n'])
                if outpoint in my_outpoints:
                    my_index = my_outpoints.index(outpoint)
                    tx._inputs[i]['value'] = my_coins[my_index]['value']
        return tx

    def read_tx_from_qrcode(self):
        data = qrscanner.scan_barcode(self.config.get_video_device())
        if not data:
            return
        # if the user scanned a bitcoin URI
        if web.is_URI(data):
            self.pay_to_URI(data)
            return
        # else if the user scanned an offline signed tx
        data = bh2u(bitcoin.base_decode(data, length=None, base=43))
        return self.tx_from_text(data)

    def read_tx_from_file(self):
        fileName = self.getOpenFileName(_("Select your transaction file"), "*.txn")
        if not fileName:
            return
        with open(fileName, "r") as f:
            file_content = f.read()
        tx_file_dict = json.loads(file_content.strip())
        return self.tx_from_text(file_content)

    def do_process_from_qrcode(self):
        try:
            tx = self.read_tx_from_qrcode()
            if tx:
                self.show_transaction(tx)
        except Exception as reason:
            self.show_critical(_("ElectrumSV was unable to read the transaction:") +
                               "\n" + str(reason))

    def do_process_from_text(self):
        text = text_dialog(self, _('Input raw transaction'), _("Transaction:"),
                           _("Load transaction"))
        try:
            tx = self.tx_from_text(text)
            if tx:
                self.show_transaction(tx)
        except (SerializationError, Exception) as reason:
            self.show_critical(_("ElectrumSV was unable to read the transaction:") +
                               "\n" + str(reason))

    def do_process_from_file(self):
        try:
            tx = self.read_tx_from_file()
            if tx:
                self.show_transaction(tx)
        except Exception as reason:
            self.show_critical(_("ElectrumSV was unable to read the transaction:") +
                               "\n" + str(reason))

    def do_process_from_txid(self):
        from electrumsv import transaction
        txid, ok = QInputDialog.getText(self, _('Lookup transaction'), _('Transaction ID') + ':')
        if ok and txid:
            txid = str(txid).strip()
            try:
                r = self.network.request_and_wait('blockchain.transaction.get', [txid])
            except Exception as exc:
                d = UntrustedMessageDialog(
                    self, _("Transaction Lookup Error"),
                    _("The server was unable to locate the transaction you specified."),
                    exc)
                d.exec()
                return
            tx = transaction.Transaction(r)
            self.show_transaction(tx)

    @protected
    def export_privkeys_dialog(self, password):
        if self.wallet.is_watching_only():
            self.show_message(_("This is a watching-only wallet"))
            return

        if isinstance(self.wallet, Multisig_Wallet):
            self.show_message(
                _('WARNING: This is a multi-signature wallet.') + '\n' +
                _('It can not be "backed up" by simply exporting these private keys.')
            )

        d = WindowModalDialog(self, _('Private keys'))
        d.setMinimumSize(850, 300)
        vbox = QVBoxLayout(d)

        msg = "\n".join([
            _("WARNING: ALL your private keys are secret."),
            _("Exposing a single private key can compromise your entire wallet!"),
            _("In particular, DO NOT use 'redeem private key' services proposed by third parties.")
        ])
        vbox.addWidget(QLabel(msg))

        e = QTextEdit()
        e.setReadOnly(True)
        vbox.addWidget(e)

        defaultname = 'electrumsv-private-keys.csv'
        select_msg = _('Select file to export your private keys to')
        hbox, filename_e, csv_button = filename_field(self, self.config, defaultname, select_msg)
        vbox.addLayout(hbox)

        b = OkButton(d, _('Export'))
        b.setEnabled(False)
        vbox.addLayout(Buttons(CancelButton(d), b))

        private_keys = {}
        addresses = self.wallet.get_addresses()
        done = False
        cancelled = False
        def privkeys_thread():
            for addr in addresses:
                time.sleep(0.1)
                if done or cancelled:
                    break
                privkey = self.wallet.export_private_key(addr, password)
                private_keys[addr.to_string()] = privkey
                self.computing_privkeys_signal.emit()
            if not cancelled:
                self.computing_privkeys_signal.disconnect()
                self.show_privkeys_signal.emit()

        def show_privkeys():
            s = "\n".join('{}\t{}'.format(addr, privkey)
                          for addr, privkey in private_keys.items())
            e.setText(s)
            b.setEnabled(True)
            self.show_privkeys_signal.disconnect()
            nonlocal done
            done = True

        def on_dialog_closed(*args):
            nonlocal done
            nonlocal cancelled
            if not done:
                cancelled = True
                self.computing_privkeys_signal.disconnect()
                self.show_privkeys_signal.disconnect()

        self.computing_privkeys_signal.connect(lambda: e.setText(
            "Please wait... %d/%d" % (len(private_keys),len(addresses))))
        self.show_privkeys_signal.connect(show_privkeys)
        d.finished.connect(on_dialog_closed)
        threading.Thread(target=privkeys_thread).start()

        if not d.exec_():
            done = True
            return

        filename = filename_e.text()
        if not filename:
            return

        try:
            self.do_export_privkeys(filename, private_keys, csv_button.isChecked())
        except (IOError, os.error) as reason:
            txt = "\n".join([
                _("ElectrumSV was unable to produce a private key-export."),
                str(reason)
            ])
            self.show_critical(txt, title=_("Unable to create csv"))

        except Exception as e:
            self.show_message(str(e))
            return

        self.show_message(_("Private keys exported."))

    def do_export_privkeys(self, fileName, pklist, is_csv):
        with open(fileName, "w+") as f:
            if is_csv:
                transaction = csv.writer(f)
                transaction.writerow(["address", "private_key"])
                for addr, pk in pklist.items():
                    transaction.writerow(["%34s"%addr,pk])
            else:
                f.write(json.dumps(pklist, indent = 4))

    def do_import_labels(self):
        labelsFile = self.getOpenFileName(_("Open labels file"), "*.json")
        if not labelsFile: return
        try:
            with open(labelsFile, 'r') as f:
                data = f.read()
            for key, value in json.loads(data).items():
                self.wallet.set_label(key, value)
            self.show_message(_("Your labels were imported from") + " '%s'" % str(labelsFile))
        except (IOError, os.error) as reason:
            self.show_critical(_("ElectrumSV was unable to import your labels.") + "\n" +
                               str(reason))
        self.address_list.update()
        self.history_list.update()
        self.history_updated_signal.emit()

    def do_export_labels(self):
        labels = self.wallet.labels
        try:
            fileName = self.getSaveFileName(_("Select file to save your labels"),
                                            'electrumsv_labels.json', "*.json")
            if fileName:
                with open(fileName, 'w+') as f:
                    json.dump(labels, f, indent=4, sort_keys=True)
                self.show_message(_("Your labels were exported to") + " '%s'" % str(fileName))
        except (IOError, os.error) as reason:
            self.show_critical(_("ElectrumSV was unable to export your labels.") + "\n" +
                               str(reason))

    def export_history_dialog(self):
        d = WindowModalDialog(self, _('Export History'))
        d.setMinimumSize(400, 200)
        vbox = QVBoxLayout(d)
        defaultname = os.path.expanduser('~/electrumsv-history.csv')
        select_msg = _('Select file to export your wallet transactions to')
        hbox, filename_e, csv_button = filename_field(self, self.config, defaultname, select_msg)
        vbox.addLayout(hbox)
        vbox.addStretch(1)
        hbox = Buttons(CancelButton(d), OkButton(d, _('Export')))
        vbox.addLayout(hbox)
        self.update()
        if not d.exec_():
            return
        filename = filename_e.text()
        if not filename:
            return
        try:
            self.do_export_history(self.wallet, filename, csv_button.isChecked())
        except (IOError, os.error) as reason:
            export_error_label = _("ElectrumSV was unable to produce a transaction export.")
            self.show_critical(export_error_label + "\n" + str(reason),
                               title=_("Unable to export history"))
            return
        self.show_message(_("Your wallet history has been successfully exported."))

    def do_export_history(self, wallet, fileName, is_csv):
        history = wallet.export_history()
        lines = []
        for item in history:
            if is_csv:
                lines.append([item['txid'], item.get('label', ''),
                              item['confirmations'], item['value'], item['date']])
            else:
                lines.append(item)

        with open(fileName, "w+") as f:
            if is_csv:
                transaction = csv.writer(f, lineterminator='\n')
                transaction.writerow(["transaction_hash", "label", "confirmations",
                                      "value", "timestamp"])
                for line in lines:
                    transaction.writerow(line)
            else:
                f.write(json.dumps(lines, indent=4))

    def sweep_key_dialog(self):
        addresses = self.wallet.get_unused_addresses()
        if not addresses:
            try:
                addresses = self.wallet.get_receiving_addresses()
            except AttributeError:
                addresses = self.wallet.get_addresses()
        if not addresses:
            self.show_warning(_('Wallet has no address to sweep to'))
            return

        d = WindowModalDialog(self, title=_('Sweep private keys'))
        d.setMinimumSize(600, 300)

        vbox = QVBoxLayout(d)
        vbox.addWidget(QLabel(_("Enter private keys:")))

        keys_e = ScanQRTextEdit(allow_multi=True)
        keys_e.setTabChangesFocus(True)
        vbox.addWidget(keys_e)

        h, addr_combo = address_combo(addresses)
        vbox.addLayout(h)

        vbox.addStretch(1)
        sweep_button = OkButton(d, _('Sweep'))
        vbox.addLayout(Buttons(CancelButton(d), sweep_button))

        def get_address_text():
            return addr_combo.currentText()

        def get_priv_keys():
            return keystore.get_private_keys(keys_e.toPlainText())

        def enable_sweep():
            sweep_button.setEnabled(bool(get_address_text()
                                         and get_priv_keys()))

        keys_e.textChanged.connect(enable_sweep)
        enable_sweep()
        if not d.exec_():
            return

        try:
            self.do_clear()
            coins, keypairs = sweep_preparations(get_priv_keys(), self.network)
            self.tx_external_keypairs = keypairs
            self.payto_e.setText(get_address_text())
            self.spend_coins(coins)
            self.spend_max()
        except Exception as e:
            self.show_message(str(e))
            return
        self.payto_e.setFrozen(True)
        self.amount_e.setFrozen(True)
        self.warn_if_watching_only()

    def _do_import(self, title, msg, func):
        text = text_dialog(self, title, msg + ' :', _('Import'),
                           allow_multi=True)
        if not text:
            return
        bad = []
        good = []
        for key in str(text).split():
            try:
                addr = func(key)
                good.append(addr)
            except Exception as e:
                bad.append(key)
                continue
        if good:
            self.show_message(_("The following addresses were added") + ':\n' + '\n'.join(good))
        if bad:
            self.show_critical(_("The following inputs could not be imported") +
                               ':\n'+ '\n'.join(bad))
        self.address_list.update()
        self.history_list.update()
        self.history_updated_signal.emit()

    def import_addresses(self):
        if not self.wallet.can_import_address():
            return
        title, msg = _('Import addresses'), _("Enter addresses")
        def import_addr(addr):
            if self.wallet.import_address(Address.from_string(addr)):
                return addr
            return ''
        self._do_import(title, msg, import_addr)

    @protected
    def do_import_privkey(self, password):
        if not self.wallet.can_import_privkey():
            return
        title, msg = _('Import private keys'), _("Enter private keys")
        self._do_import(title, msg, lambda x: self.wallet.import_private_key(x, password))

    #
    # Preferences dialog and its signals.
    #
    def on_num_zeros_changed(self):
        self.history_list.update()
        self.history_updated_signal.emit()
        self.address_list.update()

    def on_fiat_ccy_changed(self):
        '''Called when the user changes fiat currency in preferences.'''
        b = app_state.fx and app_state.fx.is_enabled()
        self.fiat_send_e.setVisible(b)
        self.fiat_receive_e.setVisible(b)
        self.history_list.refresh_headers()
        self.history_list.update()
        self.history_updated_signal.emit()
        self.address_list.refresh_headers()
        self.address_list.update()
        self.update_status()

    def on_base_unit_changed(self):
        edits = self.amount_e, self.receive_amount_e
        amounts = [edit.get_amount() for edit in edits]
        self.history_list.update()
        self.history_updated_signal.emit()
        self.request_list.update()
        self.address_list.update()
        for edit, amount in zip(edits, amounts):
            edit.setAmount(amount)
        self.update_status()
        for tx_dialog in self.tx_dialogs:
            tx_dialog.update()

    def on_fiat_history_changed(self):
        self.history_list.refresh_headers()

    def on_fiat_balance_changed(self):
        self.address_list.refresh_headers()
        self.address_list.update()

    def preferences_dialog(self):
        dialog = PreferencesDialog(self.wallet)
        dialog.exec_()

    def ok_to_close(self):
        # Close our tx dialogs; return False if any cannot be closed
        for tx_dialog in list(self.tx_dialogs):
            if not tx_dialog.close():
                return False
        return True

    def closeEvent(self, event):
        if self.ok_to_close():
            # It seems in some rare cases this closeEvent() is called twice
            if not self.cleaned_up:
                self.clean_up()
                self.cleaned_up = True
            event.accept()
        else:
            event.ignore()

    def clean_up(self):
        if self.network:
            self.network.unregister_callback(self.on_network)

        if self.tx_notify_timer:
            self.tx_notify_timer.stop()
            self.tx_notify_timer = None

        # We catch these errors with the understanding that there is no recovery at
        # this point, given user has likely performed an action we cannot recover
        # cleanly from.  So we attempt to exit as cleanly as possible.
        try:
            self.config.set_key("is_maximized", self.isMaximized())
            self.config.set_key("console-history", self.console.history[-50:], True)
        except (OSError, PermissionError):
            self.logger.exception("unable to write to config (directory removed?)")

        if not self.isMaximized():
            try:
                g = self.geometry()
                self.wallet.storage.put("winpos-qt", [g.left(),g.top(),g.width(),g.height()])
            except (OSError, PermissionError):
                self.logger.exception("unable to write to wallet storage (directory removed?)")

        # Should be no side-effects in this function relating to file access past this point.
        if self.qr_window:
            self.qr_window.close()

        for keystore in self.wallet.get_keystores():
            if isinstance(keystore, Hardware_KeyStore):
                app_state.device_manager.unpair_xpub(keystore.xpub)
        self.logger.debug(f'closing wallet {self.wallet.storage.path}')

        self.app.timer.timeout.disconnect(self.timer_actions)
        self.app.close_window(self)

    def cpfp(self, parent_tx, new_tx):
        total_size = parent_tx.estimated_size() + new_tx.estimated_size()
        d = WindowModalDialog(self, _('Child Pays for Parent'))
        vbox = QVBoxLayout(d)
        msg = (
            "A CPFP is a transaction that sends an unconfirmed output back to "
            "yourself, with a high fee. The goal is to have miners confirm "
            "the parent transaction in order to get the fee attached to the "
            "child transaction.")
        vbox.addWidget(WWLabel(_(msg)))
        msg2 = ("The proposed fee is computed using your "
            "fee/kB settings, applied to the total size of both child and "
            "parent transactions. After you broadcast a CPFP transaction, "
            "it is normal to see a new unconfirmed transaction in your history.")
        vbox.addWidget(WWLabel(_(msg2)))
        grid = QGridLayout()
        grid.addWidget(QLabel(_('Total size') + ':'), 0, 0)
        grid.addWidget(QLabel('%d bytes'% total_size), 0, 1)
        max_fee = new_tx.output_value()
        grid.addWidget(QLabel(_('Input amount') + ':'), 1, 0)
        grid.addWidget(QLabel(self.format_amount(max_fee) + ' ' + app_state.base_unit()), 1, 1)
        output_amount = QLabel('')
        grid.addWidget(QLabel(_('Output amount') + ':'), 2, 0)
        grid.addWidget(output_amount, 2, 1)
        fee_e = BTCAmountEdit()
        def f(x):
            a = max_fee - fee_e.get_amount()
            output_amount.setText((self.format_amount(a) + ' ' + app_state.base_unit())
                                  if a else '')
        fee_e.textChanged.connect(f)
        fee = self.config.fee_per_kb() * total_size / 1000
        fee_e.setAmount(fee)
        grid.addWidget(QLabel(_('Fee' + ':')), 3, 0)
        grid.addWidget(fee_e, 3, 1)
        vbox.addLayout(grid)
        vbox.addLayout(Buttons(CancelButton(d), OkButton(d)))
        if not d.exec_():
            return
        fee = fee_e.get_amount()
        if fee > max_fee:
            self.show_error(_('Max fee exceeded'))
            return
        new_tx = self.wallet.cpfp(parent_tx, fee)
        if new_tx is None:
            self.show_error(_('CPFP no longer valid'))
            return
        self.show_transaction(new_tx)
